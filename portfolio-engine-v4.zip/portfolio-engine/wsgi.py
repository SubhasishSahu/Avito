"""
wsgi.py — PythonAnywhere WSGI entry point.
In PythonAnywhere Web tab → WSGI configuration file → paste this path.
The 'application' name is required by WSGI spec.
"""
import sys, os

# Adjust this path to match your PythonAnywhere username and repo location
# e.g. /home/yourusername/portfolio-engine
project_path = os.path.dirname(os.path.abspath(__file__))
if project_path not in sys.path:
    sys.path.insert(0, project_path)

# Initialise DB on first cold start if needed
from config import DB_PATH
if not os.path.exists(DB_PATH):
    from tools.init_db import init_db
    init_db()

from app import app as application
