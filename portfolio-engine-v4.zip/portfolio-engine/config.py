"""
config.py — Central configuration for Portfolio Engine
Reads from environment variables (.env locally,
PythonAnywhere Web tab → Environment Variables in production).
"""

import os, hashlib
from dotenv import load_dotenv
load_dotenv()

# ── Authentication ─────────────────────────────────────────────────────────────
USER_EMAIL   = os.environ.get("USER_EMAIL", "").strip().lower()
SECRET_SALT  = os.environ.get("SECRET_SALT", "default-salt-change-me")
FLASK_SECRET = os.environ.get("FLASK_SECRET_KEY", "dev-secret-change-in-prod")

def generate_token(email: str) -> str:
    raw = f"{email.strip().lower()}:{SECRET_SALT}"
    return "pf_" + hashlib.sha256(raw.encode()).hexdigest()

def validate_token(token: str) -> bool:
    if not USER_EMAIL or not token:
        return False
    return token == generate_token(USER_EMAIL)

PORTFOLIO_TOKEN = generate_token(USER_EMAIL) if USER_EMAIL else None

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
DATA_DIR      = os.path.join(BASE_DIR, os.environ.get("DATA_DIR", "data"))
DB_PATH       = os.path.join(BASE_DIR, os.environ.get("DB_PATH", "data/market.db"))
PORTFOLIO_CSV = os.path.join(BASE_DIR, os.environ.get("PORTFOLIO_CSV", "data/portfolio.csv"))
WATCHLIST_CSV = os.path.join(BASE_DIR, os.environ.get("WATCHLIST_CSV", "data/watchlist.csv"))
SNAPSHOT_JSON = os.path.join(DATA_DIR, "snapshot.json")
NEWS_JSON     = os.path.join(DATA_DIR, "rss_news.json")
RESULTS_JSON  = os.path.join(DATA_DIR, "results.json")
METADATA_JSON = os.path.join(DATA_DIR, "metadata.json")
UPLOAD_DIR    = os.path.join(DATA_DIR, "uploads")

for _d in [DATA_DIR, UPLOAD_DIR]:
    os.makedirs(_d, exist_ok=True)

# ── Harvest settings ───────────────────────────────────────────────────────────
MAX_STOCKS          = int(os.environ.get("MAX_STOCKS", 100))
PRICE_HISTORY_YEARS = int(os.environ.get("PRICE_HISTORY_YEARS", 5))
HARVEST_TIMEOUT     = int(os.environ.get("HARVEST_TIMEOUT_SECONDS", 30))
NEWS_API_KEY        = os.environ.get("NEWS_API_KEY", "").strip() or None
FLASK_ENV           = os.environ.get("FLASK_ENV", "production")
DEBUG               = FLASK_ENV == "development"
NSE_SUFFIX          = ".NS"
BSE_SUFFIX          = ".BO"

# ── Nifty 50 default universe ─────────────────────────────────────────────────
NIFTY50_TICKERS = [
    "ADANIENT","ADANIPORTS","APOLLOHOSP","ASIANPAINT","AXISBANK",
    "BAJAJ-AUTO","BAJAJFINSV","BAJFINANCE","BHARTIARTL","BPCL",
    "BRITANNIA","CIPLA","COALINDIA","DIVISLAB","DRREDDY",
    "EICHERMOT","GRASIM","HCLTECH","HDFCBANK","HDFCLIFE",
    "HEROMOTOCO","HINDALCO","HINDUNILVR","ICICIBANK","INDUSINDBK",
    "INFY","ITC","JSWSTEEL","KOTAKBANK","LT",
    "M&M","MARUTI","NESTLEIND","NTPC","ONGC",
    "POWERGRID","RELIANCE","SBILIFE","SBIN","SHRIRAMFIN",
    "SUNPHARMA","TATACONSUM","TATAMOTORS","TATASTEEL","TCS",
    "TECHM","TITAN","ULTRACEMCO","WIPRO","ZOMATO",
]

NIFTY50_META = {
    "ADANIENT":   {"name":"Adani Enterprises Ltd",       "sector":"Conglomerate"},
    "ADANIPORTS": {"name":"Adani Ports & SEZ Ltd",       "sector":"Infrastructure/Port"},
    "APOLLOHOSP": {"name":"Apollo Hospitals Enterprise", "sector":"Healthcare"},
    "ASIANPAINT": {"name":"Asian Paints Ltd",            "sector":"Paints"},
    "AXISBANK":   {"name":"Axis Bank Ltd",               "sector":"Banking & Finance"},
    "BAJAJ-AUTO": {"name":"Bajaj Auto Ltd",              "sector":"Automobile"},
    "BAJAJFINSV": {"name":"Bajaj Finserv Ltd",           "sector":"Financial Services"},
    "BAJFINANCE": {"name":"Bajaj Finance Ltd",           "sector":"NBFC"},
    "BHARTIARTL": {"name":"Bharti Airtel Ltd",           "sector":"Telecom"},
    "BPCL":       {"name":"Bharat Petroleum Corp",       "sector":"Oil & Gas"},
    "BRITANNIA":  {"name":"Britannia Industries Ltd",    "sector":"FMCG"},
    "CIPLA":      {"name":"Cipla Ltd",                   "sector":"Pharma"},
    "COALINDIA":  {"name":"Coal India Ltd",              "sector":"Mining/PSU"},
    "DIVISLAB":   {"name":"Divi's Laboratories Ltd",     "sector":"Pharma"},
    "DRREDDY":    {"name":"Dr Reddy's Laboratories",     "sector":"Pharma"},
    "EICHERMOT":  {"name":"Eicher Motors Ltd",           "sector":"Automobile"},
    "GRASIM":     {"name":"Grasim Industries Ltd",       "sector":"Cement"},
    "HCLTECH":    {"name":"HCL Technologies Ltd",        "sector":"IT"},
    "HDFCBANK":   {"name":"HDFC Bank Ltd",               "sector":"Banking & Finance"},
    "HDFCLIFE":   {"name":"HDFC Life Insurance",         "sector":"Insurance"},
    "HEROMOTOCO": {"name":"Hero MotoCorp Ltd",           "sector":"Automobile"},
    "HINDALCO":   {"name":"Hindalco Industries Ltd",     "sector":"Metals/Aluminium"},
    "HINDUNILVR": {"name":"Hindustan Unilever Ltd",      "sector":"FMCG"},
    "ICICIBANK":  {"name":"ICICI Bank Ltd",              "sector":"Banking & Finance"},
    "INDUSINDBK": {"name":"IndusInd Bank Ltd",           "sector":"Banking & Finance"},
    "INFY":       {"name":"Infosys Ltd",                 "sector":"IT"},
    "ITC":        {"name":"ITC Ltd",                     "sector":"FMCG"},
    "JSWSTEEL":   {"name":"JSW Steel Ltd",               "sector":"Metals/Steel"},
    "KOTAKBANK":  {"name":"Kotak Mahindra Bank Ltd",     "sector":"Banking & Finance"},
    "LT":         {"name":"Larsen & Toubro Ltd",         "sector":"Engineering/PSU"},
    "M&M":        {"name":"Mahindra & Mahindra Ltd",     "sector":"Automobile"},
    "MARUTI":     {"name":"Maruti Suzuki India Ltd",     "sector":"Automobile"},
    "NESTLEIND":  {"name":"Nestle India Ltd",            "sector":"FMCG"},
    "NTPC":       {"name":"NTPC Ltd",                    "sector":"Power/PSU"},
    "ONGC":       {"name":"Oil & Natural Gas Corp",      "sector":"Oil & Gas"},
    "POWERGRID":  {"name":"Power Grid Corp of India",    "sector":"Power/PSU"},
    "RELIANCE":   {"name":"Reliance Industries Ltd",     "sector":"Conglomerate"},
    "SBILIFE":    {"name":"SBI Life Insurance",          "sector":"Insurance"},
    "SBIN":       {"name":"State Bank of India",         "sector":"Banking/PSU"},
    "SHRIRAMFIN": {"name":"Shriram Finance Ltd",         "sector":"NBFC"},
    "SUNPHARMA":  {"name":"Sun Pharmaceutical Ind",      "sector":"Pharma"},
    "TATACONSUM": {"name":"Tata Consumer Products",      "sector":"FMCG"},
    "TATAMOTORS": {"name":"Tata Motors Ltd",             "sector":"Automobile"},
    "TATASTEEL":  {"name":"Tata Steel Ltd",              "sector":"Metals/Steel"},
    "TCS":        {"name":"Tata Consultancy Services",   "sector":"IT"},
    "TECHM":      {"name":"Tech Mahindra Ltd",           "sector":"IT"},
    "TITAN":      {"name":"Titan Company Ltd",           "sector":"Gems & Jewellery"},
    "ULTRACEMCO": {"name":"UltraTech Cement Ltd",        "sector":"Cement"},
    "WIPRO":      {"name":"Wipro Ltd",                   "sector":"IT"},
    "ZOMATO":     {"name":"Zomato Ltd",                  "sector":"Consumer Tech"},
}

TRACKED_INDICES = {
    "NIFTY50":     {"name":"Nifty 50",             "yf":"^NSEI",          "category":"BROAD"},
    "NIFTYNEXT50": {"name":"Nifty Next 50",         "yf":"^NSMIDCP",       "category":"BROAD"},
    "NIFTYBANK":   {"name":"Nifty Bank",            "yf":"^NSEBANK",       "category":"SECTORAL"},
    "NIFTYIT":     {"name":"Nifty IT",              "yf":"^CNXIT",         "category":"SECTORAL"},
    "NIFTYPHARMA": {"name":"Nifty Pharma",          "yf":"^CNXPHARMA",     "category":"SECTORAL"},
    "NIFTYAUTO":   {"name":"Nifty Auto",            "yf":"^CNXAUTO",       "category":"SECTORAL"},
    "NIFTYFMCG":   {"name":"Nifty FMCG",           "yf":"^CNXFMCG",       "category":"SECTORAL"},
    "NIFTYINFRA":  {"name":"Nifty Infrastructure",  "yf":"^CNXINFRA",      "category":"SECTORAL"},
    "NIFTYENERGY": {"name":"Nifty Energy",          "yf":"^CNXENERGY",     "category":"SECTORAL"},
    "NIFTYMETAL":  {"name":"Nifty Metal",           "yf":"^CNXMETAL",      "category":"SECTORAL"},
    "NIFTYDEFENCE":{"name":"Nifty India Defence",   "yf":"NIFTYDEFENCE.NS","category":"THEMATIC"},
}

SECTOR_INDEX_MAP = {
    "Banking & Finance":"NIFTYBANK","Banking/PSU":"NIFTYBANK",
    "IT":"NIFTYIT","Pharma":"NIFTYPHARMA","Automobile":"NIFTYAUTO",
    "FMCG":"NIFTYFMCG","Infrastructure/Port":"NIFTYINFRA",
    "Power/PSU":"NIFTYENERGY","Oil & Gas":"NIFTYENERGY",
    "Metals/Steel":"NIFTYMETAL","Metals/Aluminium":"NIFTYMETAL",
    "Metals/Copper":"NIFTYMETAL","Defence":"NIFTYDEFENCE",
    "Defence Electronics":"NIFTYDEFENCE","Defence/Aerospace":"NIFTYDEFENCE",
    "Defence/Shipbuilding":"NIFTYDEFENCE","Defence Tech":"NIFTYDEFENCE",
}

# ── RSS Feed Catalogue — three-tier influence system ─────────────────────────
RSS_FEEDS = {
    "exchange": [
        {"id":"nse_ann",  "name":"NSE Corporate Announcements",
         "url":"https://www.nseindia.com/rss/corporatean.xml",
         "influence_tier":1,"source_tier":1,"category":"COMPANY"},
        {"id":"bse_corp", "name":"BSE Corporate Filings",
         "url":"https://www.bseindia.com/Rss/RssCorpActions.aspx",
         "influence_tier":1,"source_tier":1,"category":"COMPANY"},
        {"id":"nse_board","name":"NSE Board Meeting Notices",
         "url":"https://www.nseindia.com/rss/boardmeetings.xml",
         "influence_tier":1,"source_tier":1,"category":"COMPANY"},
    ],
    "index_sector": [
        {"id":"et_mkt",  "name":"ET Markets",
         "url":"https://economictimes.indiatimes.com/markets/rss.cms",
         "influence_tier":2,"source_tier":1,"category":"INDEX"},
        {"id":"bs_mkt",  "name":"Business Standard Markets",
         "url":"https://www.business-standard.com/rss/markets-106.rss",
         "influence_tier":2,"source_tier":1,"category":"INDEX"},
        {"id":"mint_mkt","name":"Mint Markets",
         "url":"https://www.livemint.com/rss/markets",
         "influence_tier":2,"source_tier":1,"category":"INDEX"},
        {"id":"mc_mkt",  "name":"Moneycontrol Markets",
         "url":"https://www.moneycontrol.com/rss/marketsindia.xml",
         "influence_tier":2,"source_tier":2,"category":"INDEX"},
    ],
    "global_macro": [
        {"id":"rbi",  "name":"RBI Press Releases",
         "url":"https://rbi.org.in/scripts/rss.aspx?Id=316",
         "influence_tier":3,"source_tier":1,"category":"GLOBAL"},
        {"id":"sebi", "name":"SEBI Circulars",
         "url":"https://www.sebi.gov.in/sebi_data/rss.xml",
         "influence_tier":3,"source_tier":1,"category":"GLOBAL"},
        {"id":"pib",  "name":"PIB Government News",
         "url":"https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3",
         "influence_tier":3,"source_tier":1,"category":"GLOBAL"},
    ],
}

INFLUENCE_WEIGHTS = {1: 1.00, 2: 0.60, 3: 0.35}

# ── Partial morphing rules ────────────────────────────────────────────────────
MORPH_RULES = {
    "prices":       {"missing_1_2":"forward_fill","missing_3_5":"linear",
                     "missing_gt5":"null_flag","volume_zero":"30d_median"},
    "financials":   {"quarter_missing":"sector_median","year_missing":"cagr_projection",
                     "implausible":"sector_p95"},
    "shareholding": {"quarter_missing":"carry_forward","pledge_absent":"zero_flag",
                     "over_100":"normalise"},
}

# ── Band system ───────────────────────────────────────────────────────────────
BAND_NUMERIC = {"SP":2,"P":1,"N":0,"NG":-1,"SN":-2}
BAND_LABELS  = {"SP":"Strong Positive","P":"Positive","N":"Neutral",
                "NG":"Negative","SN":"Strong Negative"}
SC_WEIGHTS   = {"SC1":1.0,"SC2":0.8,"SC3":0.6,"SC4":0.9,"SC5":0.7}
