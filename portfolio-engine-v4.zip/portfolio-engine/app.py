"""
app.py — Flask web server for Portfolio Engine
Entry point for PythonAnywhere WSGI deployment.

Endpoints:
  GET  /                       → dashboard (requires token)
  GET  /setup                  → first-time setup wizard
  POST /api/auth/verify        → validate email → return token
  GET  /api/status             → health check (public)
  GET  /api/metadata           → data freshness + quality flags
  GET  /api/portfolio          → full scored portfolio results
  GET  /api/news               → latest scored news items
  GET  /api/prices/<ticker>    → price history for one stock
  GET  /api/watchlist          → current watchlist
  POST /api/portfolio/upload   → upload new portfolio Excel/CSV
  POST /api/watchlist/add      → add ticker to watchlist
  POST /api/refresh            → manual harvest trigger
  POST /api/backtest/record    → record outcome for calibration
"""

import json, os, csv, time
from datetime import datetime
from functools import wraps
from flask import (Flask, render_template, request, jsonify,
                   redirect, url_for, send_from_directory)
import sqlite3

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    FLASK_SECRET, DEBUG, DB_PATH, PORTFOLIO_CSV, WATCHLIST_CSV,
    SNAPSHOT_JSON, NEWS_JSON, RESULTS_JSON, METADATA_JSON,
    UPLOAD_DIR, MAX_STOCKS, validate_token, generate_token,
    USER_EMAIL, NIFTY50_TICKERS, NIFTY50_META
)

app = Flask(__name__)
app.secret_key = FLASK_SECRET


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def read_json(path: str, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}

def write_json(path: str, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)

def token_from_request():
    """Extract token from Authorization header, query param, or body."""
    token = request.headers.get("X-Portfolio-Token")
    if not token:
        token = request.args.get("token")
    if not token:
        try:
            token = request.get_json(silent=True, force=True).get("token")
        except Exception:
            pass
    return token or ""

def require_auth(f):
    """Decorator — protects API routes with token validation."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = token_from_request()
        if not validate_token(token):
            return jsonify({"error": "Unauthorised", "code": 401}), 401
        return f(*args, **kwargs)
    return decorated

def require_auth_page(f):
    """Decorator — protects page routes, redirects to /setup."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = token_from_request()
        if not token:
            # Check localStorage token is handled client-side
            # For server-side check, look at cookie
            from flask import request as r
            token = r.cookies.get("pf_token", "")
        if not validate_token(token):
            return redirect("/setup")
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────────────────────
# PAGES
# ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Main dashboard — auth handled client-side via localStorage token."""
    return render_template("dashboard.html")

@app.route("/setup")
def setup():
    """First-time setup wizard."""
    return render_template("dashboard.html")  # Same SPA handles both

@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory("static", filename)


# ─────────────────────────────────────────────────────────────
# AUTH ENDPOINTS
# ─────────────────────────────────────────────────────────────

@app.route("/api/auth/verify", methods=["POST"])
def auth_verify():
    """
    Verify email → return token if it matches USER_EMAIL.
    The token is deterministic — same email always gives same token.
    Never stores email, never sends it anywhere.
    """
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()

    if not email:
        return jsonify({"error": "Email required"}), 400
    if not USER_EMAIL:
        return jsonify({"error": "App not configured — set USER_EMAIL env var"}), 503
    if email != USER_EMAIL:
        return jsonify({"error": "Email not recognised"}), 401

    token = generate_token(email)
    return jsonify({
        "token": token,
        "email": email,
        "message": "Token generated. Save your bookmark — token is stored in your browser."
    })

@app.route("/api/status", methods=["GET"])
def status():
    """Public health check — no auth required."""
    db_ok = os.path.exists(DB_PATH)
    configured = bool(USER_EMAIL)
    meta = read_json(METADATA_JSON, {})
    return jsonify({
        "status":        "ok" if db_ok and configured else "setup_required",
        "db_exists":     db_ok,
        "configured":    configured,
        "version":       "4.0.0",
        "last_harvest":  meta.get("last_price_refresh", "never"),
        "server_time":   datetime.now().isoformat(),
    })


# ─────────────────────────────────────────────────────────────
# DATA ENDPOINTS
# ─────────────────────────────────────────────────────────────

@app.route("/api/metadata", methods=["GET"])
@require_auth
def api_metadata():
    """Data freshness, quality flags, harvest status."""
    meta = read_json(METADATA_JSON, {})
    if not meta:
        # Build from DB if JSON not yet written
        if os.path.exists(DB_PATH):
            with get_db() as conn:
                row = conn.execute("""
                    SELECT job_name, completed_at, status, stocks_updated
                    FROM harvest_log
                    ORDER BY log_id DESC LIMIT 5
                """).fetchall()
                meta["recent_harvests"] = [dict(r) for r in row]
        meta["status"] = "initialising"
    return jsonify(meta)

@app.route("/api/portfolio", methods=["GET"])
@require_auth
def api_portfolio():
    """
    Full scored portfolio.
    Reads pre-computed results.json — fast, no computation at request time.
    Falls back to raw portfolio_holdings if results not yet computed.
    """
    results = read_json(RESULTS_JSON)
    if results:
        return jsonify(results)

    # Fallback: return raw holdings from DB
    if not os.path.exists(DB_PATH):
        return jsonify({"holdings": [], "summary": {}, "status": "no_data"})

    with get_db() as conn:
        rows = conn.execute("SELECT * FROM portfolio_holdings").fetchall()
        holdings = [dict(r) for r in rows]

    return jsonify({
        "holdings": holdings,
        "summary":  {},
        "status":   "raw_data",
        "message":  "Scorecards not yet computed — run harvest first"
    })

@app.route("/api/news", methods=["GET"])
@require_auth
def api_news():
    """Latest scored news items, optionally filtered by ticker or category."""
    ticker   = request.args.get("ticker")
    category = request.args.get("category")   # COMPANY | INDEX | GLOBAL
    limit    = min(int(request.args.get("limit", 50)), 200)

    news = read_json(NEWS_JSON)
    if news:
        items = news.get("items", [])
        if ticker:
            items = [i for i in items
                     if i.get("relevant_ticker") == ticker]
        if category:
            items = [i for i in items
                     if i.get("news_category") == category]
        return jsonify({"items": items[:limit],
                        "total": len(items),
                        "as_of": news.get("as_of")})

    # Fallback: query DB directly
    if not os.path.exists(DB_PATH):
        return jsonify({"items": [], "total": 0})

    with get_db() as conn:
        query  = "SELECT * FROM news_items WHERE 1=1"
        params = []
        if ticker:
            query += " AND relevant_ticker = ?"; params.append(ticker)
        if category:
            query += " AND news_category = ?"; params.append(category)
        query += " ORDER BY published_date DESC, influence_tier ASC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()

    return jsonify({"items": [dict(r) for r in rows], "total": len(rows)})

@app.route("/api/prices/<ticker>", methods=["GET"])
@require_auth
def api_prices(ticker: str):
    """Price history for a single stock. Defaults to last 252 trading days."""
    days  = min(int(request.args.get("days", 252)), 1260)  # max 5y
    ticker = ticker.upper().strip()

    if not os.path.exists(DB_PATH):
        return jsonify({"ticker": ticker, "prices": [], "error": "No database"})

    with get_db() as conn:
        rows = conn.execute("""
            SELECT price_date, open, high, low, close, adj_close,
                   volume, data_quality
            FROM daily_prices
            WHERE ticker = ?
            ORDER BY price_date DESC
            LIMIT ?
        """, (ticker, days)).fetchall()

    prices = [dict(r) for r in rows]
    prices.reverse()  # chronological order for charting

    return jsonify({
        "ticker": ticker,
        "count":  len(prices),
        "prices": prices,
    })

@app.route("/api/snapshot/<ticker>", methods=["GET"])
@require_auth
def api_snapshot(ticker: str):
    """Pre-computed analytics snapshot for a stock (Beta, VaR, fundamentals)."""
    ticker = ticker.upper().strip()
    snapshot = read_json(SNAPSHOT_JSON, {})
    if ticker in snapshot:
        return jsonify(snapshot[ticker])

    if not os.path.exists(DB_PATH):
        return jsonify({"error": "No data"}), 404

    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM analytics_snapshot WHERE ticker = ?", (ticker,)
        ).fetchone()

    if not row:
        return jsonify({"error": f"No snapshot for {ticker}"}), 404
    return jsonify(dict(row))

@app.route("/api/watchlist", methods=["GET"])
@require_auth
def api_watchlist():
    """Current watchlist — all tracked stocks."""
    if not os.path.exists(DB_PATH):
        return jsonify({"stocks": NIFTY50_TICKERS, "source": "default"})

    with get_db() as conn:
        rows = conn.execute("""
            SELECT ticker, company_name, sector, index_member,
                   in_portfolio, in_watchlist, market_cap_cat
            FROM stocks WHERE is_active = 1
            ORDER BY in_portfolio DESC, ticker ASC
        """).fetchall()

    return jsonify({
        "stocks":  [dict(r) for r in rows],
        "total":   len(rows),
        "max":     MAX_STOCKS,
    })


# ─────────────────────────────────────────────────────────────
# UPLOAD & MANAGEMENT ENDPOINTS
# ─────────────────────────────────────────────────────────────

@app.route("/api/portfolio/upload", methods=["POST"])
@require_auth
def api_portfolio_upload():
    """
    Upload portfolio Excel (.xlsx) or CSV file.
    Parses tickers, validates against stocks table,
    returns {valid, unrecognised, duplicates} for user confirmation.
    Saves to data/portfolio.csv only after /api/portfolio/confirm.
    """
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    f       = request.files["file"]
    fname   = f.filename.lower()
    ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmppath = os.path.join(UPLOAD_DIR, f"upload_{ts}_{fname}")
    f.save(tmppath)

    try:
        rows = _parse_portfolio_file(tmppath)
    except Exception as e:
        os.remove(tmppath)
        return jsonify({"error": f"Parse error: {e}"}), 400

    # Validate tickers
    valid, unrecognised, duplicates = _validate_tickers(rows)

    # Store parsed rows in a temp JSON for confirmation step
    tmp_json = os.path.join(UPLOAD_DIR, f"pending_{ts}.json")
    write_json(tmp_json, {"rows": rows, "source_file": fname, "ts": ts})

    return jsonify({
        "pending_id":    ts,
        "total_rows":    len(rows),
        "valid":         valid,
        "unrecognised":  unrecognised,
        "duplicates":    duplicates,
        "message":       f"Review {len(unrecognised)} unrecognised tickers, "
                         f"then POST /api/portfolio/confirm with pending_id"
    })

@app.route("/api/portfolio/confirm", methods=["POST"])
@require_auth
def api_portfolio_confirm():
    """
    Confirm the pending upload — saves portfolio.csv and updates DB.
    Optionally accepts list of tickers to exclude (user rejected unrecognised).
    """
    data       = request.get_json(force=True, silent=True) or {}
    pending_id = data.get("pending_id")
    exclude    = set(data.get("exclude", []))

    if not pending_id:
        return jsonify({"error": "pending_id required"}), 400

    tmp_json = os.path.join(UPLOAD_DIR, f"pending_{pending_id}.json")
    if not os.path.exists(tmp_json):
        return jsonify({"error": "Pending upload not found or expired"}), 404

    pending = read_json(tmp_json)
    rows    = [r for r in pending["rows"]
               if r.get("ticker") not in exclude]

    # Save to portfolio.csv
    _save_portfolio_csv(rows)

    # Update DB
    _update_portfolio_db(rows)

    # Clean up temp files
    os.remove(tmp_json)

    return jsonify({
        "saved":   len(rows),
        "excluded":len(exclude),
        "message": "Portfolio saved. Trigger harvest to refresh scores.",
    })

@app.route("/api/watchlist/add", methods=["POST"])
@require_auth
def api_watchlist_add():
    """Add one or more tickers to the watchlist (max 100 total)."""
    data    = request.get_json(force=True, silent=True) or {}
    tickers = [t.upper().strip() for t in data.get("tickers", [])
               if t.strip()]

    if not tickers:
        return jsonify({"error": "No tickers provided"}), 400

    if not os.path.exists(DB_PATH):
        return jsonify({"error": "Database not initialised"}), 503

    with get_db() as conn:
        current_count = conn.execute(
            "SELECT COUNT(*) FROM stocks WHERE is_active=1"
        ).fetchone()[0]

        available = MAX_STOCKS - current_count
        to_add    = tickers[:available]
        skipped   = tickers[available:]
        added     = []

        for ticker in to_add:
            try:
                conn.execute("""
                    INSERT OR IGNORE INTO stocks
                    (ticker, company_name, listing_exchange,
                     yf_ticker, is_active, in_watchlist, added_date)
                    VALUES (?, ?, 'NSE', ?, 1, 1, ?)
                """, (ticker, ticker, ticker + ".NS",
                      datetime.now().strftime("%Y-%m-%d")))
                added.append(ticker)
            except Exception:
                pass
        conn.commit()

    return jsonify({
        "added":   added,
        "skipped": skipped,
        "reason":  f"Max {MAX_STOCKS} stocks reached" if skipped else None,
        "total":   current_count + len(added),
    })


# ─────────────────────────────────────────────────────────────
# HARVEST & BACKTEST ENDPOINTS
# ─────────────────────────────────────────────────────────────

@app.route("/api/refresh", methods=["POST"])
@require_auth
def api_refresh():
    """
    Trigger manual harvest. Runs asynchronously (fire-and-forget).
    On PythonAnywhere free tier: runs synchronously but with timeout guard.
    Returns immediately with job_id — poll /api/metadata for completion.
    """
    data = request.get_json(force=True, silent=True) or {}
    jobs = data.get("jobs", ["prices", "news"])   # subset to run

    # On PythonAnywhere the scheduled task handles full harvest.
    # Manual refresh is lightweight: prices + news only by default.
    try:
        from harvest.scheduler import run_jobs
        job_id = run_jobs(jobs, async_mode=False)
        return jsonify({"status": "started", "job_id": job_id, "jobs": jobs})
    except ImportError:
        return jsonify({
            "status":  "unavailable",
            "message": "Harvest module not yet installed. "
                       "Run: python tools/init_db.py first."
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/backtest/record", methods=["POST"])
@require_auth
def api_backtest_record():
    """
    Record a backtest outcome to improve SC6 calibration.
    Body: {ticker, scorecard_key, predicted_band, actual_direction, days_elapsed}
    """
    data = request.get_json(force=True, silent=True) or {}
    required = ["ticker", "scorecard_key", "predicted_band", "actual_direction"]
    for field in required:
        if not data.get(field):
            return jsonify({"error": f"{field} required"}), 400

    ticker    = data["ticker"].upper()
    sc_key    = data["scorecard_key"]
    pred_band = data["predicted_band"].upper()
    actual    = data["actual_direction"].lower()
    days      = int(data.get("days_elapsed", 10))

    pred_pos  = pred_band in ("SP", "P")
    pred_neg  = pred_band in ("SN", "NG")
    correct   = ((pred_pos and actual == "up") or
                 (pred_neg and actual == "down") or
                 (pred_band == "N" and actual == "flat"))

    if not os.path.exists(DB_PATH):
        return jsonify({"error": "Database not initialised"}), 503

    with get_db() as conn:
        # Log outcome
        conn.execute("""
            INSERT INTO backtest_outcomes
            (ticker, scorecard_key, predicted_band, actual_direction,
             recorded_at, days_elapsed, was_correct)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (ticker, sc_key, pred_band, actual,
              datetime.now().isoformat(), days, int(correct)))

        # EMA update: new = 0.8*old + 0.2*outcome
        cal_key = f"{sc_key}:{ticker}"
        row = conn.execute(
            "SELECT accuracy, observations FROM backtest_calibration WHERE cal_key=?",
            (cal_key,)
        ).fetchone()

        old_acc = row["accuracy"] if row else 0.52
        new_acc = 0.8 * old_acc + 0.2 * (1.0 if correct else 0.0)

        conn.execute("""
            INSERT INTO backtest_calibration (cal_key, accuracy, observations, last_updated)
            VALUES (?, ?, 1, ?)
            ON CONFLICT(cal_key) DO UPDATE SET
                accuracy     = ?,
                observations = observations + 1,
                last_updated = ?
        """, (cal_key, new_acc, datetime.now().isoformat(),
              new_acc, datetime.now().isoformat()))
        conn.commit()

    return jsonify({
        "ticker":       ticker,
        "cal_key":      cal_key,
        "was_correct":  correct,
        "old_accuracy": round(old_acc, 4),
        "new_accuracy": round(new_acc, 4),
    })


# ─────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────

def _parse_portfolio_file(path: str) -> list:
    """Parse uploaded Excel or CSV into list of row dicts."""
    ext = path.lower().rsplit(".", 1)[-1]
    rows = []

    if ext in ("xlsx", "xls"):
        import openpyxl
        wb   = openpyxl.load_workbook(path, data_only=True)
        ws   = wb.active
        headers = [str(c.value or "").strip() for c in next(ws.iter_rows())]
        for row in ws.iter_rows(min_row=2, values_only=True):
            rows.append(dict(zip(headers, [str(v or "").strip() for v in row])))
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            rows   = [dict(r) for r in reader]

    # Normalise column names → canonical keys
    canonical = {}
    col_map = {
        "stock name": "ticker",  "ticker": "ticker",
        "symbol": "ticker",      "nse code": "ticker",
        "company name": "company_name",
        "qty": "qty",            "quantity": "qty",
        "cmp": "cmp",            "ltp": "cmp",
        "average cost value": "avg_cost", "avg cost": "avg_cost",
        "invested value": "invested_value",
        "current value": "current_value",
        "unrealized profit/loss": "unrealised_pnl",
        "unrealised profit/loss": "unrealised_pnl",
        "% chg": "unrealised_pnl_pct",
        "realized profit/loss": "realised_pnl",
        "realised profit/loss": "realised_pnl",
        "long term qty": "lt_qty", "short term qty": "st_qty",
        "days profit/loss": "days_pnl",
        "% change": "pct_change",
        "portfolio holdings": "portfolio_type",
    }

    result = []
    for raw in rows:
        norm = {}
        for k, v in raw.items():
            mapped = col_map.get(k.lower().strip(), k.lower().strip())
            norm[mapped] = v.strip().replace(",", "") if isinstance(v, str) else v
        if norm.get("ticker"):
            norm["ticker"] = norm["ticker"].upper().strip()
            result.append(norm)

    return result

def _validate_tickers(rows: list):
    """Validate tickers against stocks table. Returns (valid, unrecognised, duplicates)."""
    seen = set()
    valid, unrecognised, duplicates = [], [], []

    if os.path.exists(DB_PATH):
        with get_db() as conn:
            known = {r[0] for r in
                     conn.execute("SELECT ticker FROM stocks").fetchall()}
    else:
        known = set(NIFTY50_TICKERS)

    for row in rows:
        t = row.get("ticker", "").upper()
        if not t:
            continue
        if t in seen:
            duplicates.append(t)
        elif t in known:
            valid.append(t); seen.add(t)
        else:
            # Also accept if ticker without EQ suffix matches known
            t2 = t.replace("EQ", "")
            if t2 in known:
                row["ticker"] = t2
                valid.append(t2); seen.add(t2)
            else:
                unrecognised.append(t); seen.add(t)

    return valid, unrecognised, duplicates

def _save_portfolio_csv(rows: list):
    """Write validated rows to data/portfolio.csv."""
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    os.makedirs(os.path.dirname(PORTFOLIO_CSV), exist_ok=True)
    with open(PORTFOLIO_CSV, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

def _update_portfolio_db(rows: list):
    """Upsert portfolio holdings into DB and mark stocks as in_portfolio."""
    if not os.path.exists(DB_PATH) or not rows:
        return
    today = datetime.now().strftime("%Y-%m-%d")

    def _f(d, k, default=0.0):
        v = str(d.get(k, "") or "").replace(",", "")
        try: return float(v)
        except: return default

    def _i(d, k, default=0):
        v = str(d.get(k, "") or "").replace(",", "")
        try: return int(float(v))
        except: return default

    with get_db() as conn:
        # Reset in_portfolio flag
        conn.execute("UPDATE stocks SET in_portfolio=0")

        for row in rows:
            ticker = row.get("ticker", "").upper()
            if not ticker:
                continue

            conn.execute("""
                INSERT INTO portfolio_holdings
                (ticker, company_name, qty, lt_qty, st_qty, avg_cost,
                 invested_value, current_value, cmp, unrealised_pnl,
                 unrealised_pnl_pct, realised_pnl, days_pnl,
                 pct_change, portfolio_type, last_updated)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(ticker) DO UPDATE SET
                    company_name=excluded.company_name, qty=excluded.qty,
                    lt_qty=excluded.lt_qty, st_qty=excluded.st_qty,
                    avg_cost=excluded.avg_cost,
                    invested_value=excluded.invested_value,
                    current_value=excluded.current_value, cmp=excluded.cmp,
                    unrealised_pnl=excluded.unrealised_pnl,
                    unrealised_pnl_pct=excluded.unrealised_pnl_pct,
                    realised_pnl=excluded.realised_pnl,
                    days_pnl=excluded.days_pnl, pct_change=excluded.pct_change,
                    portfolio_type=excluded.portfolio_type,
                    last_updated=excluded.last_updated
            """, (
                ticker,
                row.get("company_name", ticker),
                _i(row, "qty"), _i(row, "lt_qty"), _i(row, "st_qty"),
                _f(row, "avg_cost"), _f(row, "invested_value"),
                _f(row, "current_value"), _f(row, "cmp"),
                _f(row, "unrealised_pnl"), _f(row, "unrealised_pnl_pct"),
                _f(row, "realised_pnl"), _f(row, "days_pnl"),
                _f(row, "pct_change"),
                row.get("portfolio_type", "Equity"),
                today,
            ))

            # Ensure stock exists in stocks table
            conn.execute("""
                INSERT OR IGNORE INTO stocks
                (ticker, company_name, listing_exchange,
                 yf_ticker, is_active, in_portfolio, in_watchlist, added_date)
                VALUES (?, ?, 'NSE', ?, 1, 1, 1, ?)
            """, (ticker, row.get("company_name", ticker),
                  ticker + ".NS", today))

            conn.execute(
                "UPDATE stocks SET in_portfolio=1 WHERE ticker=?", (ticker,))

        conn.commit()


# ─────────────────────────────────────────────────────────────
# WSGI ENTRY POINT
# ─────────────────────────────────────────────────────────────

# PythonAnywhere WSGI file should import 'app' from this module:
#   from app import app as application

if __name__ == "__main__":
    # Local development only
    from tools.init_db import init_db
    if not os.path.exists(DB_PATH):
        print("First run — initialising database...")
        init_db()
    app.run(debug=DEBUG, port=5000, host="0.0.0.0")
