"""
harvest/shareholding.py — Fetches quarterly shareholding pattern via yfinance.
Runs monthly (1st of month). Writes to shareholding_pattern table.
Computes 4-quarter trend slopes. Applies carry-forward morphing for gaps.
"""
import sys, os, time, json
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH, MORPH_RULES
import sqlite3

try:
    import yfinance as yf
    HAS_YF = True
except ImportError:
    HAS_YF = False

def get_db():
    conn = sqlite3.connect(DB_PATH); conn.row_factory = sqlite3.Row; return conn

def _safe(val, default=None):
    try:
        f = float(val)
        return None if (f != f) else f
    except Exception:
        return default

def _trend_slope(values: list) -> float:
    """Linear regression slope over a list of values. Returns None if insufficient."""
    n = len([v for v in values if v is not None])
    if n < 3:
        return None
    import statistics
    clean = [v for v in values if v is not None]
    x_mean = (len(clean)-1) / 2
    y_mean = statistics.mean(clean)
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(clean))
    den = sum((i - x_mean)**2 for i in range(len(clean)))
    return round(num / den, 4) if den else None

def run_shareholding() -> dict:
    if not HAS_YF:
        return {"updated":0,"failed":0,"error":"yfinance not installed"}

    with get_db() as conn:
        tickers = [(r["ticker"], r["yf_ticker"] or r["ticker"]+".NS")
                   for r in conn.execute(
                       "SELECT ticker,yf_ticker FROM stocks WHERE is_active=1"
                   ).fetchall()]

    updated, failed, errors = 0, 0, []
    fetched_at = datetime.now().isoformat()

    for idx, (ticker, yf_ticker) in enumerate(tickers):
        try:
            tk = yf.Ticker(yf_ticker)
            # yfinance major_holders gives promoter/institution breakdown
            mh = tk.major_holders
            ih = tk.institutional_holders

            if mh is None or mh.empty:
                failed += 1
                errors.append(f"{ticker}: no holder data")
                continue

            # Parse major_holders (index 0=insiders%, 1=institutions%, etc.)
            promoter_pct = None
            fii_pct      = None
            dii_pct      = None
            public_pct   = None

            try:
                rows_mh = mh.values.tolist()
                for row in rows_mh:
                    label = str(row[1]).lower() if len(row) > 1 else ""
                    val   = _safe(str(row[0]).replace("%",""))
                    if "insider" in label or "promoter" in label:
                        promoter_pct = val
                    elif "institution" in label:
                        fii_pct = val   # approximate: institutions ≈ FII+DII
            except Exception:
                pass

            if promoter_pct is None and fii_pct is None:
                failed += 1; errors.append(f"{ticker}: could not parse holders")
                continue

            # Quarter end: use current quarter end date
            now = datetime.now()
            q_month = ((now.month - 1) // 3) * 3 + 3
            quarter_end = datetime(now.year, q_month,
                                   30 if q_month in (6,9) else
                                   31 if q_month == 3 else 31).strftime("%Y-%m-%d")

            # Estimate DII / public from total
            if promoter_pct and fii_pct:
                dii_pct    = max(0, 100 - promoter_pct - fii_pct - 10)
                public_pct = max(0, 100 - promoter_pct - fii_pct - dii_pct)

            # Morphing: if any value is None, carry forward from last quarter
            quality  = "full"
            morphed  = []
            with get_db() as conn:
                prev = conn.execute("""
                    SELECT * FROM shareholding_pattern
                    WHERE ticker=? ORDER BY quarter_end DESC LIMIT 1
                """, (ticker,)).fetchone()

            if promoter_pct is None and prev:
                promoter_pct = prev["promoter_pct"]
                morphed.append("promoter_pct"); quality = "partial_morphed"

            # Compute 4-quarter trend slope
            with get_db() as conn:
                hist = conn.execute("""
                    SELECT promoter_pct, fii_pct, dii_pct
                    FROM shareholding_pattern
                    WHERE ticker=? ORDER BY quarter_end DESC LIMIT 4
                """, (ticker,)).fetchall()

            p_vals = [r["promoter_pct"] for r in hist] + [promoter_pct]
            f_vals = [r["fii_pct"]      for r in hist] + [fii_pct]
            d_vals = [r["dii_pct"]      for r in hist] + [dii_pct]

            p_trend = _trend_slope(list(reversed(p_vals)))
            f_trend = _trend_slope(list(reversed(f_vals)))
            d_trend = _trend_slope(list(reversed(d_vals)))

            with get_db() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO shareholding_pattern
                    (ticker,quarter_end,promoter_pct,promoter_pledge_pct,
                     fii_pct,dii_pct,public_pct,
                     promoter_trend_4q,fii_trend_4q,dii_trend_4q,
                     data_quality,morphed_fields,data_source,fetched_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (ticker, quarter_end,
                      promoter_pct, 0.0,   # pledge not reliably in yfinance
                      fii_pct, dii_pct, public_pct,
                      p_trend, f_trend, d_trend,
                      quality, json.dumps(morphed), "yfinance", fetched_at))
                conn.commit()
            updated += 1

            if idx % 10 == 0:
                print(f"    [{idx+1}/{len(tickers)}] {ticker} shareholding ok")
            time.sleep(0.4)

        except Exception as e:
            failed += 1; errors.append(f"{ticker}: {e}")

    return {"updated": updated, "failed": failed, "errors": errors}

def run():
    return run_shareholding()
