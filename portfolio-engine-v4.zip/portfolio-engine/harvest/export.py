"""
harvest/export.py — Writes all pre-computed JSON files consumed by dashboard.
Runs last in the harvest sequence.
Outputs: snapshot.json, results.json, metadata.json (updated)
"""
import sys, os, json
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (DB_PATH, SNAPSHOT_JSON, RESULTS_JSON,
                    NEWS_JSON, DATA_DIR, BAND_NUMERIC)
import sqlite3

def get_db():
    conn = sqlite3.connect(DB_PATH); conn.row_factory = sqlite3.Row; return conn

def run_export() -> dict:
    if not os.path.exists(DB_PATH):
        return {"updated": 0, "failed": 1, "error": "no database"}

    os.makedirs(DATA_DIR, exist_ok=True)
    exported = 0

    # ── snapshot.json — analytics per stock ───────────────────────────────
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM analytics_snapshot").fetchall()
    snapshot = {r["ticker"]: dict(r) for r in rows}
    with open(SNAPSHOT_JSON, "w") as f:
        json.dump(snapshot, f, indent=2, default=str)
    exported += len(snapshot)
    print(f"    snapshot.json: {len(snapshot)} stocks")

    # ── results.json — full scorecard output ──────────────────────────────
    with get_db() as conn:
        holdings = conn.execute(
            "SELECT * FROM portfolio_holdings"
        ).fetchall()
        analytics = {r["ticker"]: dict(r)
                     for r in conn.execute(
                         "SELECT * FROM analytics_snapshot"
                     ).fetchall()}
        news_by_ticker = {}
        news_rows = conn.execute("""
            SELECT relevant_ticker, headline, sentiment, influence_tier,
                   influence_weight, published_date, source_name, news_category
            FROM news_items
            WHERE published_date >= date('now','-7 days')
            ORDER BY influence_tier ASC, published_date DESC
        """).fetchall()
        for nr in news_rows:
            t = nr["relevant_ticker"]
            if t:
                news_by_ticker.setdefault(t, []).append(dict(nr))

    results_holdings = []
    for h in holdings:
        t = h["ticker"]
        an = analytics.get(t, {})
        news = news_by_ticker.get(t, [])

        # Quick scorecard estimate from analytics
        sc1_band = _sc1_band(h, an)
        sc3_band = _sc3_band(news)
        sc4_band = _sc4_band(an)
        decision = _decision(sc1_band, sc3_band, sc4_band)

        results_holdings.append({
            **dict(h),
            "analytics":    an,
            "news_items":   news[:5],
            "sc1_band":     sc1_band,
            "sc3_band":     sc3_band,
            "sc4_band":     sc4_band,
            "decision_band":decision,
            "alpha_vs_nifty":  an.get("alpha_vs_nifty"),
            "alpha_vs_sector": an.get("alpha_vs_sector"),
            "beta_1y":         an.get("beta_1y"),
            "var_95_1d_pct":   an.get("var_95_1d_pct"),
            "promoter_change_1y":   an.get("promoter_change_1y"),
            "promoter_pledge_pct":  an.get("promoter_pledge_pct"),
            "data_quality":    an.get("data_quality", "unknown"),
        })

    # Sort: decision band desc, then unrealised_pnl desc
    results_holdings.sort(
        key=lambda h: (BAND_NUMERIC.get(h["decision_band"], 0),
                       h.get("unrealised_pnl", 0)),
        reverse=True
    )

    # Portfolio summary
    total_invested = sum(h["invested_value"] or 0 for h in holdings)
    total_current  = sum(h["current_value"]  or 0 for h in holdings)
    total_upnl     = sum(h["unrealised_pnl"] or 0 for h in holdings)

    results = {
        "as_of":    datetime.now().isoformat(),
        "summary":  {
            "total_invested":  total_invested,
            "total_current":   total_current,
            "unrealised_pnl":  total_upnl,
            "return_pct":      round(total_upnl/total_invested*100, 2)
                               if total_invested else 0,
            "num_holdings":    len(holdings),
            "winners":  sum(1 for h in holdings if (h["unrealised_pnl"] or 0) > 0),
            "losers":   sum(1 for h in holdings if (h["unrealised_pnl"] or 0) < 0),
        },
        "holdings": results_holdings,
    }

    with open(RESULTS_JSON, "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"    results.json: {len(results_holdings)} holdings")
    exported += len(results_holdings)

    return {"updated": exported, "failed": 0}

def _sc1_band(holding, analytics: dict) -> str:
    """Quick SC1 estimate from analytics data."""
    score = 0
    pnl_pct = holding["unrealised_pnl_pct"] or 0
    if pnl_pct > 100: score += 50
    elif pnl_pct > 50: score += 30
    elif pnl_pct > 15: score += 15
    elif pnl_pct < -25: score -= 50
    elif pnl_pct < -10: score -= 25

    roe = analytics.get("roe_ttm")
    if roe:
        if roe > 20: score += 20
        elif roe > 12: score += 10
        elif roe < 5: score -= 15

    alpha = analytics.get("alpha_vs_nifty")
    if alpha:
        if alpha > 10: score += 15
        elif alpha < -10: score -= 15

    pledge = analytics.get("promoter_pledge_pct") or 0
    if pledge > 30: score -= 25
    elif pledge > 10: score -= 10

    return _score_to_band(score)

def _sc3_band(news_items: list) -> str:
    if not news_items:
        return "N"
    score = 0
    for item in news_items[:5]:
        w = item.get("influence_weight", 0.35)
        s = item.get("sentiment", "neutral")
        score += {"positive":1,"neutral":0,"negative":-1}.get(s, 0) * w * 40
    return _score_to_band(score)

def _sc4_band(analytics: dict) -> str:
    sector_alpha = analytics.get("alpha_vs_sector")
    nifty_alpha  = analytics.get("alpha_vs_nifty")
    if sector_alpha is None:
        return "N"
    score = 0
    if sector_alpha > 15: score += 40
    elif sector_alpha > 5: score += 20
    elif sector_alpha < -15: score -= 40
    elif sector_alpha < -5: score -= 20
    if nifty_alpha and nifty_alpha > 10: score += 10
    return _score_to_band(score)

def _score_to_band(score: float) -> str:
    if score >= 50: return "SP"
    if score >= 20: return "P"
    if score >= -20: return "N"
    if score >= -50: return "NG"
    return "SN"

def _decision(sc1: str, sc3: str, sc4: str) -> str:
    nums = [BAND_NUMERIC.get(b, 0) for b in [sc1, sc3, sc4]]
    weights = [1.0, 0.6, 0.9]
    wavg = sum(n*w for n,w in zip(nums,weights)) / sum(weights)
    if wavg >= 1.4: return "SP"
    if wavg >= 0.5: return "P"
    if wavg >= -0.5: return "N"
    if wavg >= -1.4: return "NG"
    return "SN"

def run():
    return run_export()
