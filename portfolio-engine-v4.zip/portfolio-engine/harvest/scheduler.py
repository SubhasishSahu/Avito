"""
harvest/scheduler.py — Daily harvest orchestrator.
PythonAnywhere scheduled task calls:
    python harvest/scheduler.py

Sequence:
  1. prices.py      — daily price + volume for all active stocks + indices
  2. news.py        — RSS three-tier feed fetch + sentiment scoring
  3. fundamentals.py — weekly (Monday only) financial statements
  4. shareholding.py — monthly (1st of month) shareholding patterns
  5. analytics.py   — compute Beta, VaR, trends, write analytics_snapshot
  6. export.py      — write snapshot.json, results.json, metadata.json
"""

import sys, os, json, time, uuid
from datetime import datetime, date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH, METADATA_JSON, DATA_DIR

import sqlite3

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)

def log_harvest(conn, job_name, started, completed,
                updated=0, failed=0, errors=None, status="success"):
    conn.execute("""
        INSERT INTO harvest_log
        (job_name, started_at, completed_at,
         stocks_updated, stocks_failed, error_details, status)
        VALUES (?,?,?,?,?,?,?)
    """, (job_name, started.isoformat(), completed.isoformat(),
          updated, failed, json.dumps(errors or []), status))
    conn.commit()

def should_run(job: str, today: date) -> bool:
    """
    Determine if a job should run today based on its schedule.
    prices, news  → every trading day (Mon-Fri)
    fundamentals  → every Monday (weekly refresh)
    shareholding  → 1st of every month (quarterly data check)
    analytics     → every trading day (after prices)
    """
    if today.weekday() >= 5:   # Saturday=5, Sunday=6
        return job in ()       # Nothing runs on weekends by default
    if job in ("prices", "news", "analytics", "export"):
        return True
    if job == "fundamentals":
        return today.weekday() == 0   # Monday
    if job == "shareholding":
        return today.day == 1         # 1st of month
    return False

def run_jobs(jobs: list = None, async_mode: bool = False) -> str:
    """
    Run specified harvest jobs in sequence.
    Returns job_id for status tracking.
    """
    job_id   = str(uuid.uuid4())[:8]
    today    = date.today()
    all_jobs = ["prices", "news", "fundamentals", "shareholding",
                "analytics", "export"]
    jobs     = jobs or [j for j in all_jobs if should_run(j, today)]

    print(f"\n{'═'*60}")
    print(f"  Portfolio Engine — Harvest Run [{job_id}]")
    print(f"  Date: {today}  |  Jobs: {', '.join(jobs)}")
    print(f"{'═'*60}")

    results = {}
    for job in jobs:
        if job not in all_jobs:
            print(f"  ⚠  Unknown job: {job} — skipped")
            continue
        print(f"\n  ▶ {job.upper()} starting…")
        t0 = datetime.now()
        try:
            result = _dispatch(job)
            elapsed = (datetime.now() - t0).seconds
            results[job] = {**result, "elapsed_s": elapsed, "status": "ok"}
            print(f"  ✔ {job} complete in {elapsed}s "
                  f"({result.get('updated',0)} updated, "
                  f"{result.get('failed',0)} failed)")
        except Exception as e:
            elapsed = (datetime.now() - t0).seconds
            results[job] = {"status": "error", "error": str(e),
                            "elapsed_s": elapsed}
            print(f"  ✗ {job} FAILED: {e}")

        if os.path.exists(DB_PATH):
            with get_db() as conn:
                log_harvest(
                    conn, job,
                    t0, datetime.now(),
                    results[job].get("updated", 0),
                    results[job].get("failed", 0),
                    results[job].get("errors"),
                    results[job].get("status", "error"),
                )

    # Update metadata.json
    meta = _build_metadata(results, today)
    write_json(METADATA_JSON, meta)

    print(f"\n{'─'*60}")
    print(f"  Harvest complete. Job ID: {job_id}")
    ok = sum(1 for r in results.values() if r.get("status") == "ok")
    print(f"  {ok}/{len(results)} jobs succeeded.")
    print(f"{'─'*60}\n")
    return job_id

def _dispatch(job: str) -> dict:
    """Import and run individual harvest module."""
    if job == "prices":
        from harvest.prices import run as run_prices
        return run_prices()
    elif job == "news":
        from harvest.news import run as run_news
        return run_news()
    elif job == "fundamentals":
        from harvest.fundamentals import run as run_fundamentals
        return run_fundamentals()
    elif job == "shareholding":
        from harvest.shareholding import run as run_shareholding
        return run_shareholding()
    elif job == "analytics":
        from harvest.analytics import run as run_analytics
        return run_analytics()
    elif job == "export":
        from harvest.export import run as run_export
        return run_export()
    return {"updated": 0, "failed": 0}

def _build_metadata(results: dict, today) -> dict:
    """Build metadata.json from harvest results."""
    now = datetime.now().isoformat()
    meta = {
        "last_run":              now,
        "run_date":              str(today),
        "jobs":                  results,
    }
    if results.get("prices", {}).get("status") == "ok":
        meta["last_price_refresh"]       = now
        meta["stocks_price_updated"]     = results["prices"].get("updated", 0)
        meta["stocks_price_failed"]      = results["prices"].get("failed", 0)
    if results.get("news", {}).get("status") == "ok":
        meta["last_news_refresh"]        = now
        meta["news_items_fetched"]       = results["news"].get("updated", 0)
    if results.get("fundamentals", {}).get("status") == "ok":
        meta["last_fundamental_refresh"] = now
    if results.get("shareholding", {}).get("status") == "ok":
        meta["last_shareholding_refresh"]= now
    if results.get("analytics", {}).get("status") == "ok":
        meta["last_analytics_compute"]   = now
        meta["stocks_with_full_data"]    = results["analytics"].get("full", 0)
        meta["stocks_with_partial_data"] = results["analytics"].get("partial", 0)
        meta["stocks_with_no_data"]      = results["analytics"].get("empty", 0)
    meta["schema_version"] = "4.0"
    meta["data_source"]    = "yfinance + NSE/BSE RSS"
    return meta

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Portfolio Engine Harvest Scheduler")
    p.add_argument("--jobs", nargs="+",
                   choices=["prices","news","fundamentals",
                            "shareholding","analytics","export","all"],
                   help="Jobs to run (default: auto based on day)")
    p.add_argument("--force", action="store_true",
                   help="Run even on weekends")
    args = p.parse_args()

    today = date.today()
    if today.weekday() >= 5 and not args.force:
        print(f"  Weekend ({today.strftime('%A')}) — skipping harvest.")
        print("  Use --force to run anyway.")
        sys.exit(0)

    jobs = None
    if args.jobs:
        jobs = (["prices","news","fundamentals","shareholding","analytics","export"]
                if "all" in args.jobs else args.jobs)

    run_jobs(jobs)
