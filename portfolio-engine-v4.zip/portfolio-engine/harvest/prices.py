"""
harvest/prices.py — Fetches daily price + volume data via yfinance.
Writes to daily_prices and index_prices tables.
Applies partial morphing rules for missing data.
"""

import sys, os, time, json
from datetime import datetime, timedelta, date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (DB_PATH, PRICE_HISTORY_YEARS, HARVEST_TIMEOUT,
                    NSE_SUFFIX, TRACKED_INDICES, MORPH_RULES)
import sqlite3

try:
    import yfinance as yf
    import pandas as pd
    HAS_YF = True
except ImportError:
    HAS_YF = False

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def log_quality(conn, ticker, domain, issue, field,
                orig, morphed, method):
    conn.execute("""
        INSERT INTO data_quality_log
        (ticker,domain,issue_type,field_name,original_value,
         morphed_value,morphed_method,logged_at)
        VALUES(?,?,?,?,?,?,?,?)
    """, (ticker, domain, issue, field, str(orig),
          str(morphed), method, datetime.now().isoformat()))

def _get_active_tickers(conn) -> list:
    rows = conn.execute(
        "SELECT ticker, yf_ticker FROM stocks WHERE is_active=1"
    ).fetchall()
    return [(r["ticker"], r["yf_ticker"] or r["ticker"]+".NS")
            for r in rows]

def _latest_date_in_db(conn, ticker: str) -> str:
    row = conn.execute(
        "SELECT MAX(price_date) FROM daily_prices WHERE ticker=?",
        (ticker,)
    ).fetchone()
    return row[0] if row and row[0] else None

def _fetch_yf(yf_ticker: str, start: str, end: str):
    """Fetch OHLCV from yfinance. Returns DataFrame or None."""
    if not HAS_YF:
        return None
    try:
        tk   = yf.Ticker(yf_ticker)
        hist = tk.history(start=start, end=end, auto_adjust=True)
        if hist.empty:
            return None
        return hist
    except Exception as e:
        print(f"    yfinance error for {yf_ticker}: {e}")
        return None

def _apply_morph_prices(df, ticker: str, conn) -> list:
    """
    Apply partial morphing rules to price DataFrame.
    Returns list of row tuples ready for DB insert.
    """
    if df is None or df.empty:
        return []

    rules  = MORPH_RULES["prices"]
    rows   = []
    prev_close = None

    df.index = df.index.tz_localize(None)  # strip timezone

    for dt, row in df.iterrows():
        price_date   = dt.strftime("%Y-%m-%d")
        o, h, l, c   = row.get("Open"), row.get("High"), row.get("Low"), row.get("Close")
        v            = row.get("Volume", 0)
        data_quality = "full"
        morphed      = []

        # Volume = 0 → morph to 30-day median (store None for now, computed in analytics)
        if v == 0 or v is None:
            v            = None
            data_quality = "partial"
            morphed.append("volume")
            log_quality(conn, ticker, "prices", "missing",
                        "volume", 0, "null_flagged", rules["volume_zero"])

        # Implausible price guard (>50% single-day move → flag)
        if prev_close and c and prev_close > 0:
            pct = abs(c - prev_close) / prev_close * 100
            if pct > 50:
                data_quality = "partial"
                morphed.append("close_outlier")
                log_quality(conn, ticker, "prices", "outlier",
                            "close", c, prev_close, "prev_close")

        if c:
            prev_close = c

        quality_str = "full" if not morphed else "partial_morphed"
        rows.append((ticker, price_date, o, h, l, c, c, v,
                     "yfinance", quality_str))
    return rows

def _fill_gaps(conn, ticker: str):
    """
    Forward-fill missing trading days (1-2 day gaps) in daily_prices.
    Larger gaps are left as NULL with a flag in data_quality_log.
    """
    rows = conn.execute("""
        SELECT price_date, close FROM daily_prices
        WHERE ticker=? ORDER BY price_date
    """, (ticker,)).fetchall()
    if len(rows) < 2:
        return

    from datetime import timedelta
    dates = [r["price_date"] for r in rows]
    close_map = {r["price_date"]: r["close"] for r in rows}
    filled = 0

    for i in range(1, len(dates)):
        d1 = datetime.strptime(dates[i-1], "%Y-%m-%d")
        d2 = datetime.strptime(dates[i],   "%Y-%m-%d")
        gap_days = (d2 - d1).days - 1
        if 1 <= gap_days <= 2:      # Forward fill 1-2 missing days
            for g in range(1, gap_days + 1):
                fill_date = (d1 + timedelta(days=g)).strftime("%Y-%m-%d")
                prev_close = close_map.get(dates[i-1])
                conn.execute("""
                    INSERT OR IGNORE INTO daily_prices
                    (ticker, price_date, open, high, low, close,
                     adj_close, volume, data_source, data_quality)
                    VALUES (?,?,?,?,?,?,?,NULL,'forward_fill','partial_morphed')
                """, (ticker, fill_date, prev_close, prev_close,
                      prev_close, prev_close, prev_close))
                log_quality(conn, ticker, "prices", "missing",
                            "all_ohlc", None, prev_close, "forward_fill")
                filled += 1
        elif gap_days > 5:
            log_quality(conn, ticker, "prices", "large_gap",
                        "all_ohlc", f"{gap_days} days", "null",
                        "data_unavailable")
    if filled:
        conn.commit()

def run_prices() -> dict:
    """Main entry point — fetch prices for all active stocks."""
    if not HAS_YF:
        return {"updated":0,"failed":0,"error":"yfinance not installed"}

    today    = date.today()
    end_date = today.strftime("%Y-%m-%d")
    updated, failed, errors = 0, 0, []

    with get_db() as conn:
        tickers = _get_active_tickers(conn)

    print(f"    Fetching prices for {len(tickers)} stocks…")

    for idx, (ticker, yf_ticker) in enumerate(tickers):
        try:
            with get_db() as conn:
                latest = _latest_date_in_db(conn, ticker)

            if latest:
                # Incremental: fetch from day after latest
                start_dt  = datetime.strptime(latest, "%Y-%m-%d") + timedelta(days=1)
                start_date = start_dt.strftime("%Y-%m-%d")
                if start_dt.date() >= today:
                    continue    # Already up to date
            else:
                # Full backfill
                start_date = (today - timedelta(days=365 * PRICE_HISTORY_YEARS)
                              ).strftime("%Y-%m-%d")

            df = _fetch_yf(yf_ticker, start_date, end_date)

            with get_db() as conn:
                rows = _apply_morph_prices(df, ticker, conn)
                if rows:
                    conn.executemany("""
                        INSERT OR REPLACE INTO daily_prices
                        (ticker,price_date,open,high,low,close,adj_close,
                         volume,data_source,data_quality)
                        VALUES(?,?,?,?,?,?,?,?,?,?)
                    """, rows)
                    conn.commit()
                    _fill_gaps(conn, ticker)
                    updated += 1
                else:
                    failed += 1
                    errors.append(f"{ticker}: no data returned")

                conn.execute(
                    "UPDATE stocks SET last_updated=? WHERE ticker=?",
                    (datetime.now().isoformat(), ticker))
                conn.commit()

            if idx % 10 == 0:
                print(f"    [{idx+1}/{len(tickers)}] {ticker} done")
            time.sleep(0.3)   # polite delay between requests

        except Exception as e:
            failed += 1
            errors.append(f"{ticker}: {str(e)}")
            print(f"    ✗ {ticker} failed: {e}")

    # Fetch index prices
    print(f"\n    Fetching {len(TRACKED_INDICES)} index price series…")
    idx_updated = 0
    for idx_id, meta in TRACKED_INDICES.items():
        try:
            with get_db() as conn:
                latest = conn.execute(
                    "SELECT MAX(price_date) FROM index_prices WHERE index_id=?",
                    (idx_id,)
                ).fetchone()[0]
            start = latest or (
                today - timedelta(days=365*PRICE_HISTORY_YEARS)
            ).strftime("%Y-%m-%d")

            df = _fetch_yf(meta["yf"], start, end_date)
            if df is not None and not df.empty:
                df.index = df.index.tz_localize(None)
                rows = [
                    (idx_id, dt.strftime("%Y-%m-%d"),
                     row.get("Open"), row.get("High"),
                     row.get("Low"), row.get("Close"),
                     int(row.get("Volume", 0) or 0))
                    for dt, row in df.iterrows()
                ]
                with get_db() as conn:
                    conn.executemany("""
                        INSERT OR REPLACE INTO index_prices
                        (index_id,price_date,open,high,low,close,volume)
                        VALUES(?,?,?,?,?,?,?)
                    """, rows)
                    conn.commit()
                idx_updated += 1
            time.sleep(0.3)
        except Exception as e:
            print(f"    ✗ Index {idx_id} failed: {e}")

    print(f"    Indices: {idx_updated}/{len(TRACKED_INDICES)} updated")
    return {"updated": updated, "failed": failed, "errors": errors}

# Alias for scheduler dispatcher
def run():
    return run_prices()
