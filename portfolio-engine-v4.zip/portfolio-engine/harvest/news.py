"""
harvest/news.py — Three-tier RSS news harvester.
Tier 1: Company Specific  (influence 1.00) — exchange announcements
Tier 2: Index / Sector    (influence 0.60) — financial press + Nifty
Tier 3: Global / Macro    (influence 0.35) — RBI, SEBI, global news

Writes to news_items table and exports rss_news.json.
"""

import sys, os, re, hashlib, json, time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (DB_PATH, RSS_FEEDS, INFLUENCE_WEIGHTS,
                    NEWS_JSON, DATA_DIR)

import sqlite3
try:
    import feedparser; HAS_FP = True
except ImportError:
    HAS_FP = False
try:
    import requests; HAS_REQ = True
except ImportError:
    HAS_REQ = False

POSITIVE_KW = [
    "order win","contract award","record profit","beats estimate",
    "strong demand","export approval","capacity expansion","acquisition",
    "PLI approved","dividend","bonus","buyback","rating upgrade",
    "strategic partnership","new order","record revenue","debt free",
    "profit jump","surge","breakthrough","approved","record high",
    "outperform","buy recommendation","target raised",
]
NEGATIVE_KW = [
    "fraud","irregularities","NPA","default","penalty","loss",
    "bankruptcy","restructuring","recall","ban","investigation",
    "downgrade","miss estimate","plant shutdown","strike","tariff",
    "sanction","price war","debt restructure","promoter pledge",
    "SEBI notice","IT raid","ED probe","insolvency","weak demand",
    "margin pressure","write-off","slump","profit warning","sell",
    "target cut","underperform",
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _fingerprint(headline: str) -> str:
    norm = re.sub(r"\W+", " ", headline.lower()).strip()
    return "n_" + hashlib.md5(norm[:80].encode()).hexdigest()[:14]

def _classify(headline: str, snippet: str = "") -> tuple:
    text = (headline + " " + snippet).lower()
    pos  = sum(1 for k in POSITIVE_KW if k in text)
    neg  = sum(1 for k in NEGATIVE_KW if k in text)
    if pos == 0 and neg == 0:
        return "neutral", 0.0
    total = pos + neg
    if pos > neg:
        return "positive", round((pos-neg)/total, 3)
    return "negative", round(-(neg-pos)/total, 3)

def _parse_date(entry) -> str:
    """Extract published date from feedparser entry."""
    if hasattr(entry, "published_parsed") and entry.published_parsed:
        try:
            return datetime(*entry.published_parsed[:6]).strftime("%Y-%m-%d")
        except Exception:
            pass
    if hasattr(entry, "updated_parsed") and entry.updated_parsed:
        try:
            return datetime(*entry.updated_parsed[:6]).strftime("%Y-%m-%d")
        except Exception:
            pass
    return datetime.now().strftime("%Y-%m-%d")

def _ticker_keywords(ticker: str, company: str) -> list:
    """Build match keywords from ticker + company name."""
    raw = re.sub(r"EQ$", "", ticker, flags=re.IGNORECASE).upper()
    words = [w for w in company.split()
             if len(w) > 2 and
             w.lower() not in ("ltd","limited","pvt","private",
                               "india","the","and","of","corp")]
    return list(dict.fromkeys([raw] + [w.lower() for w in words[:3]]))

def _matches(text: str, keywords: list, threshold: int = 1) -> bool:
    tl = text.lower()
    return sum(1 for k in keywords if k.lower() in tl) >= threshold

def _fetch_feed(feed_meta: dict, timeout: int = 10) -> list:
    """Fetch one RSS feed. Returns list of raw entry dicts."""
    if not HAS_REQ:
        return []
    url = feed_meta["url"]
    try:
        resp = requests.get(
            url, timeout=timeout,
            headers={"User-Agent": "PortfolioEngine/4.0 (India Equity Research)"}
        )
        if resp.status_code != 200:
            return []
        content = resp.text
    except Exception as e:
        print(f"      Feed fetch error [{feed_meta['id']}]: {e}")
        return []

    entries = []
    if HAS_FP:
        parsed = feedparser.parse(content)
        for e in parsed.entries[:30]:
            entries.append({
                "title":   getattr(e, "title",   "") or "",
                "summary": (getattr(e, "summary", "") or "")[:200],
                "link":    getattr(e, "link",    "") or "",
                "date":    _parse_date(e),
            })
    else:
        # stdlib XML fallback
        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(content)
            for item in root.iter("item"):
                entries.append({
                    "title":   (item.findtext("title") or "").strip(),
                    "summary": (item.findtext("description") or "")[:200],
                    "link":    (item.findtext("link") or "").strip(),
                    "date":    datetime.now().strftime("%Y-%m-%d"),
                })
        except Exception:
            pass
    return entries

def _get_portfolio_stocks(conn) -> list:
    """Return list of (ticker, company_name, sector) for active stocks."""
    rows = conn.execute("""
        SELECT s.ticker, s.company_name, s.sector
        FROM stocks s
        WHERE s.is_active=1
    """).fetchall()
    return [(r["ticker"], r["company_name"] or r["ticker"],
             r["sector"] or "Unknown") for r in rows]

def run_news() -> dict:
    """Fetch all RSS feeds, classify items, write to DB + JSON."""
    if not HAS_REQ:
        return {"updated": 0, "failed": 0,
                "error": "requests not installed"}

    cutoff  = (datetime.now() - timedelta(days=14)).strftime("%Y-%m-%d")
    fetched_at = datetime.now().isoformat()
    seen_ids   = set()
    all_items  = []
    total_inserted = 0

    with get_db() as conn:
        portfolio_stocks = _get_portfolio_stocks(conn)
        # Pre-load existing item IDs to avoid re-inserting
        existing = {r[0] for r in conn.execute(
            "SELECT item_id FROM news_items WHERE published_date >= ?",
            (cutoff,)
        ).fetchall()}
        seen_ids.update(existing)

    print(f"    Portfolio stocks: {len(portfolio_stocks)}")
    print(f"    Existing news items (last 14d): {len(existing)}")

    # ── Iterate all three feed categories ─────────────────────────────────
    for category, feeds in RSS_FEEDS.items():
        for feed_meta in feeds:
            if not feed_meta.get("is_active", True):
                continue

            print(f"    Fetching [{feed_meta['influence_tier']}] "
                  f"{feed_meta['name']}…", end=" ")
            entries = _fetch_feed(feed_meta)
            print(f"{len(entries)} entries")

            influence_tier   = feed_meta["influence_tier"]
            influence_weight = INFLUENCE_WEIGHTS[influence_tier]
            source_tier      = feed_meta["source_tier"]
            news_category    = feed_meta["category"]  # COMPANY|INDEX|GLOBAL

            for entry in entries:
                headline = entry["title"].strip()
                if not headline or len(headline) < 10:
                    continue
                pub_date = entry["date"]
                if pub_date < cutoff:
                    continue

                snippet = entry["summary"]
                link    = entry["link"]
                item_id = _fingerprint(headline)

                if item_id in seen_ids:
                    continue
                seen_ids.add(item_id)

                sentiment, score = _classify(headline, snippet)

                # ── Determine relevance ────────────────────────────────────
                relevant_ticker = None
                relevant_index  = None
                relevant_sector = None

                if news_category == "COMPANY":
                    # Try to match to a specific stock
                    combined = headline + " " + snippet
                    for ticker, company, sector in portfolio_stocks:
                        kw = _ticker_keywords(ticker, company)
                        if _matches(combined, kw, threshold=1):
                            relevant_ticker = ticker
                            relevant_sector = sector
                            # Company match → boost influence weight
                            influence_weight = INFLUENCE_WEIGHTS[1]
                            break

                elif news_category == "INDEX":
                    # Match to indices or sectors
                    combined = headline + " " + snippet
                    index_keywords = {
                        "nifty bank": "NIFTYBANK",
                        "nifty it": "NIFTYIT",
                        "nifty pharma": "NIFTYPHARMA",
                        "nifty auto": "NIFTYAUTO",
                        "nifty fmcg": "NIFTYFMCG",
                        "nifty metal": "NIFTYMETAL",
                        "nifty energy": "NIFTYENERGY",
                        "nifty infra": "NIFTYINFRA",
                        "nifty defence": "NIFTYDEFENCE",
                        "nifty 50": "NIFTY50",
                        "sensex": "NIFTY50",
                    }
                    combined_lower = combined.lower()
                    for kw, idx in index_keywords.items():
                        if kw in combined_lower:
                            relevant_index = idx
                            break
                    # Also check if a specific portfolio stock is mentioned
                    for ticker, company, sector in portfolio_stocks:
                        kw = _ticker_keywords(ticker, company)
                        if _matches(combined, kw, threshold=2):
                            relevant_ticker = ticker
                            relevant_sector = sector
                            break

                # Backtest weight from calibration
                bt_key  = f"news:{news_category}"
                bt_weight = 0.55  # default seed

                item = {
                    "item_id":          item_id,
                    "headline":         headline,
                    "snippet":          snippet[:200],
                    "source_name":      feed_meta["name"],
                    "source_url":       link,
                    "published_date":   pub_date,
                    "fetched_at":       fetched_at,
                    "news_category":    news_category,
                    "influence_tier":   influence_tier,
                    "influence_weight": influence_weight,
                    "relevant_ticker":  relevant_ticker,
                    "relevant_index":   relevant_index,
                    "relevant_sector":  relevant_sector,
                    "sentiment":        sentiment,
                    "sentiment_score":  score,
                    "source_tier":      source_tier,
                    "backtest_weight":  bt_weight,
                    "feed_id":          feed_meta["id"],
                    "feed_category":    category,
                }
                all_items.append(item)

            # Update rss_feeds last_fetched
            with get_db() as conn:
                conn.execute("""
                    UPDATE rss_feeds SET last_fetched=?, last_item_count=?
                    WHERE feed_id=?
                """, (fetched_at, len(entries), feed_meta["id"]))
                conn.commit()

            time.sleep(0.5)  # polite delay between feeds

    # ── Write to database ──────────────────────────────────────────────────
    if all_items:
        with get_db() as conn:
            for item in all_items:
                try:
                    conn.execute("""
                        INSERT OR IGNORE INTO news_items
                        (item_id,headline,snippet,source_name,source_url,
                         published_date,fetched_at,news_category,influence_tier,
                         influence_weight,relevant_ticker,relevant_index,
                         relevant_sector,sentiment,sentiment_score,source_tier,
                         backtest_weight,feed_id,feed_category)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        item["item_id"],item["headline"],item["snippet"],
                        item["source_name"],item["source_url"],
                        item["published_date"],item["fetched_at"],
                        item["news_category"],item["influence_tier"],
                        item["influence_weight"],item["relevant_ticker"],
                        item["relevant_index"],item["relevant_sector"],
                        item["sentiment"],item["sentiment_score"],
                        item["source_tier"],item["backtest_weight"],
                        item["feed_id"],item["feed_category"],
                    ))
                    total_inserted += 1
                except Exception as e:
                    pass
            conn.commit()

        # Prune items older than 30 days
        with get_db() as conn:
            old_cutoff = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
            conn.execute("DELETE FROM news_items WHERE published_date < ?",
                         (old_cutoff,))
            conn.commit()

    # ── Export to JSON ─────────────────────────────────────────────────────
    _export_news_json()

    print(f"    News: {total_inserted} new items inserted")
    return {"updated": total_inserted, "failed": 0}

def _export_news_json():
    """Write rss_news.json — the file the dashboard reads."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT * FROM news_items
            WHERE published_date >= date('now','-14 days')
            ORDER BY influence_tier ASC, published_date DESC
            LIMIT 500
        """).fetchall()

    items = [dict(r) for r in rows]
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(NEWS_JSON, "w") as f:
        json.dump({
            "as_of": datetime.now().isoformat(),
            "total": len(items),
            "items": items,
        }, f, indent=2, default=str)

def run():
    return run_news()
