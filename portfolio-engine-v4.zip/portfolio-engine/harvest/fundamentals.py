"""
harvest/fundamentals.py — Fetches financial statements via yfinance.
Runs weekly (Monday). Writes to financial_statements + valuation_metrics.
Missing data is morphed per MORPH_RULES["financials"].
"""
import sys, os, time, json
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH, MORPH_RULES
import sqlite3

try:
    import yfinance as yf
    import pandas as pd
    HAS_YF = True
except ImportError:
    HAS_YF = False

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _safe(val, default=None):
    try:
        f = float(val)
        return None if (f != f) else f   # NaN check
    except Exception:
        return default

def run_fundamentals() -> dict:
    if not HAS_YF:
        return {"updated":0,"failed":0,"error":"yfinance not installed"}

    with get_db() as conn:
        tickers = [(r["ticker"], r["yf_ticker"] or r["ticker"]+".NS")
                   for r in conn.execute(
                       "SELECT ticker,yf_ticker FROM stocks WHERE is_active=1"
                   ).fetchall()]

    updated, failed, errors = 0, 0, []
    fetched_at = datetime.now().isoformat()
    today = datetime.now().strftime("%Y-%m-%d")

    # Compute sector medians from existing data (for morphing)
    sector_medians = _compute_sector_medians()

    for idx, (ticker, yf_ticker) in enumerate(tickers):
        try:
            tk = yf.Ticker(yf_ticker)

            # Annual financials
            try:
                inc = tk.financials          # income statement
                bal = tk.balance_sheet       # balance sheet
                _write_annual(ticker, inc, bal, sector_medians,
                              fetched_at, today)
            except Exception as e:
                errors.append(f"{ticker} annual: {e}")

            # Quarterly financials
            try:
                inc_q = tk.quarterly_financials
                bal_q = tk.quarterly_balance_sheet
                _write_quarterly(ticker, inc_q, bal_q, sector_medians,
                                 fetched_at, today)
            except Exception as e:
                errors.append(f"{ticker} quarterly: {e}")

            # Valuation metrics (live)
            try:
                info = tk.fast_info
                _write_valuation(ticker, info, today, fetched_at)
            except Exception as e:
                errors.append(f"{ticker} valuation: {e}")

            updated += 1
            if idx % 10 == 0:
                print(f"    [{idx+1}/{len(tickers)}] {ticker} fundamentals ok")
            time.sleep(0.5)

        except Exception as e:
            failed += 1
            errors.append(f"{ticker}: {e}")
            print(f"    ✗ {ticker} fundamentals failed: {e}")

    return {"updated": updated, "failed": failed, "errors": errors}

def _write_annual(ticker, inc, bal, sector_medians, fetched_at, today):
    if inc is None or inc.empty:
        return
    with get_db() as conn:
        for col in inc.columns:
            try:
                period_end = col.strftime("%Y-%m-%d") if hasattr(col,"strftime") else str(col)[:10]
                revenue   = _safe(inc.loc["Total Revenue", col] if "Total Revenue" in inc.index else None)
                pat       = _safe(inc.loc["Net Income", col]    if "Net Income"    in inc.index else None)
                ebitda    = _safe(inc.loc["EBITDA", col]        if "EBITDA"        in inc.index else None)
                eps       = _safe(inc.loc["Diluted EPS", col]   if "Diluted EPS"   in inc.index else None)

                debt    = None
                equity  = None
                cash    = None
                if bal is not None and not bal.empty and col in bal.columns:
                    debt   = _safe(bal.loc["Total Debt", col]         if "Total Debt"         in bal.index else None)
                    equity = _safe(bal.loc["Stockholders Equity", col]if "Stockholders Equity" in bal.index else None)
                    cash   = _safe(bal.loc["Cash And Cash Equivalents",col]
                                   if "Cash And Cash Equivalents" in bal.index else None)

                morphed = []
                quality = "full"

                # ROE, D/E computation
                roe = None
                if pat is not None and equity and equity != 0:
                    roe = pat / equity * 100
                debt_to_equity = None
                if debt is not None and equity and equity != 0:
                    debt_to_equity = debt / equity

                # Morph missing PAT with sector median
                if pat is None:
                    sm = sector_medians.get(ticker, {}).get("pat_median")
                    if sm:
                        pat = sm; morphed.append("pat"); quality = "partial_morphed"

                conn.execute("""
                    INSERT OR REPLACE INTO financial_statements
                    (ticker,period_end,period_type,revenue,pat,ebitda,eps,
                     total_debt,cash_equivalents,total_equity,roe,debt_to_equity,
                     data_quality,morphed_fields,data_source,fetched_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (ticker, period_end, "ANNUAL",
                      revenue, pat, ebitda, eps,
                      debt, cash, equity, roe, debt_to_equity,
                      quality, json.dumps(morphed), "yfinance", fetched_at))
            except Exception:
                pass
        conn.commit()

def _write_quarterly(ticker, inc_q, bal_q, sector_medians, fetched_at, today):
    if inc_q is None or inc_q.empty:
        return
    with get_db() as conn:
        for col in inc_q.columns[:8]:   # Last 8 quarters max
            try:
                period_end = col.strftime("%Y-%m-%d") if hasattr(col,"strftime") else str(col)[:10]
                revenue = _safe(inc_q.loc["Total Revenue", col] if "Total Revenue" in inc_q.index else None)
                pat     = _safe(inc_q.loc["Net Income", col]    if "Net Income"    in inc_q.index else None)
                conn.execute("""
                    INSERT OR REPLACE INTO financial_statements
                    (ticker,period_end,period_type,revenue,pat,
                     data_quality,data_source,fetched_at)
                    VALUES(?,?,?,?,?,?,?,?)
                """, (ticker, period_end, "QUARTERLY",
                      revenue, pat, "full", "yfinance", fetched_at))
            except Exception:
                pass
        conn.commit()

def _write_valuation(ticker, info, today, fetched_at):
    with get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO valuation_metrics
            (ticker,metric_date,pe_ratio,pb_ratio,market_cap,
             dividend_yield,data_quality,fetched_at)
            VALUES(?,?,?,?,?,?,?,?)
        """, (ticker, today,
              _safe(getattr(info,"pe_forward",None)),
              _safe(getattr(info,"price_to_book",None)),
              _safe(getattr(info,"market_cap",None)),
              _safe(getattr(info,"three_month_average_volume",None)),
              "full", fetched_at))
        conn.commit()

def _compute_sector_medians() -> dict:
    """Return {ticker: {metric: sector_median}} for morphing."""
    if not os.path.exists(DB_PATH):
        return {}
    try:
        with get_db() as conn:
            rows = conn.execute("""
                SELECT s.ticker, s.sector, fs.pat
                FROM financial_statements fs
                JOIN stocks s ON s.ticker=fs.ticker
                WHERE fs.period_type='ANNUAL' AND fs.pat IS NOT NULL
                ORDER BY fs.period_end DESC
            """).fetchall()
    except Exception:
        return {}

    from collections import defaultdict
    sector_pats = defaultdict(list)
    ticker_sector = {}
    for r in rows:
        sector_pats[r["sector"]].append(r["pat"])
        ticker_sector[r["ticker"]] = r["sector"]

    result = {}
    for ticker, sector in ticker_sector.items():
        pats = sector_pats.get(sector, [])
        if pats:
            sorted_p = sorted(pats)
            n = len(sorted_p)
            median = sorted_p[n//2] if n % 2 else (sorted_p[n//2-1]+sorted_p[n//2])/2
            result[ticker] = {"pat_median": median}
    return result

def run():
    return run_fundamentals()
