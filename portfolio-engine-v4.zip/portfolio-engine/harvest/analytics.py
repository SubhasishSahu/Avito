"""
harvest/analytics.py — Computes all derived metrics from raw DB data.
Writes to analytics_snapshot table.
Runs daily after prices are updated.

Metrics computed:
  Beta (1y vs Nifty 50, sector index)
  VaR 95% 1-day
  Volatility (annualised)
  Max Drawdown (1y)
  Returns (1m, 3m, 6m, 1y)
  Relative returns vs sector and Nifty
  Revenue / PAT CAGR (3y)
  Debt trend slope
  ROE, ROCE TTM
  Shareholding changes
"""
import sys, os, json, math
from datetime import datetime, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH, SECTOR_INDEX_MAP
import sqlite3

try:
    import numpy as np
    HAS_NP = True
except ImportError:
    HAS_NP = False

def get_db():
    conn = sqlite3.connect(DB_PATH); conn.row_factory = sqlite3.Row; return conn

def _returns_series(conn, ticker: str, days: int) -> list:
    cutoff = (datetime.now() - timedelta(days=days+5)).strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT close FROM daily_prices
        WHERE ticker=? AND price_date>=? AND close IS NOT NULL
        ORDER BY price_date
        LIMIT ?
    """, (ticker, cutoff, days)).fetchall()
    closes = [r["close"] for r in rows]
    if len(closes) < 2:
        return []
    return [(closes[i]-closes[i-1])/closes[i-1]
            for i in range(1, len(closes))]

def _index_returns(conn, index_id: str, days: int) -> list:
    cutoff = (datetime.now() - timedelta(days=days+5)).strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT close FROM index_prices
        WHERE index_id=? AND price_date>=? AND close IS NOT NULL
        ORDER BY price_date LIMIT ?
    """, (index_id, cutoff, days)).fetchall()
    closes = [r["close"] for r in rows]
    if len(closes) < 2:
        return []
    return [(closes[i]-closes[i-1])/closes[i-1]
            for i in range(1, len(closes))]

def _beta(stock_rets: list, market_rets: list) -> float:
    n = min(len(stock_rets), len(market_rets))
    if n < 20:
        return None
    s = stock_rets[-n:]; m = market_rets[-n:]
    if not HAS_NP:
        sm = sum(a*b for a,b in zip(s,m))/n - (sum(s)/n)*(sum(m)/n)
        mm = sum(x**2 for x in m)/n - (sum(m)/n)**2
        return round(sm/mm, 3) if mm else None
    cov = float(np.cov(s, m)[0][1])
    var = float(np.var(m))
    return round(cov/var, 3) if var else None

def _var95(rets: list) -> float:
    if len(rets) < 20:
        return None
    s = sorted(rets)
    idx = max(0, int(len(s)*0.05))
    return round(s[idx]*100, 3)

def _vol(rets: list) -> float:
    if len(rets) < 20:
        return None
    n = len(rets)
    mean = sum(rets)/n
    var  = sum((x-mean)**2 for x in rets)/(n-1)
    return round(math.sqrt(var)*math.sqrt(252)*100, 2)

def _max_drawdown(conn, ticker: str, days: int = 252) -> float:
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT close FROM daily_prices
        WHERE ticker=? AND price_date>=? AND close IS NOT NULL
        ORDER BY price_date
    """, (ticker, cutoff)).fetchall()
    closes = [r["close"] for r in rows]
    if len(closes) < 10:
        return None
    peak = closes[0]; mdd = 0
    for c in closes[1:]:
        if c > peak: peak = c
        dd = (peak - c) / peak
        if dd > mdd: mdd = dd
    return round(-mdd*100, 2)

def _period_return(conn, ticker: str, days: int) -> float:
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT close FROM daily_prices
        WHERE ticker=? AND price_date>=? AND close IS NOT NULL
        ORDER BY price_date
    """, (ticker, cutoff)).fetchall()
    if len(rows) < 2:
        return None
    c_start = rows[0]["close"]; c_end = rows[-1]["close"]
    if c_start <= 0:
        return None
    return round((c_end - c_start)/c_start*100, 2)

def _index_period_return(conn, index_id: str, days: int) -> float:
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT close FROM index_prices
        WHERE index_id=? AND price_date>=? AND close IS NOT NULL
        ORDER BY price_date
    """, (index_id, cutoff)).fetchall()
    if len(rows) < 2:
        return None
    c0 = rows[0]["close"]; c1 = rows[-1]["close"]
    return round((c1-c0)/c0*100, 2) if c0 > 0 else None

def _cagr(values: list, years: int) -> float:
    clean = [v for v in values if v is not None and v > 0]
    if len(clean) < 2:
        return None
    start = clean[0]; end = clean[-1]
    if start <= 0 or years <= 0:
        return None
    return round(((end/start)**(1/years) - 1)*100, 2)

def _linear_slope(values: list) -> float:
    clean = [(i, v) for i, v in enumerate(values) if v is not None]
    n = len(clean)
    if n < 3:
        return None
    xs = [c[0] for c in clean]; ys = [c[1] for c in clean]
    xm = sum(xs)/n; ym = sum(ys)/n
    num = sum((x-xm)*(y-ym) for x,y in zip(xs,ys))
    den = sum((x-xm)**2 for x in xs)
    return round(num/den, 4) if den else None

def run_analytics() -> dict:
    if not os.path.exists(DB_PATH):
        return {"updated":0,"failed":0,"error":"no database"}

    with get_db() as conn:
        tickers = [(r["ticker"], r["sector"] or "Unknown")
                   for r in conn.execute(
                       "SELECT ticker,sector FROM stocks WHERE is_active=1"
                   ).fetchall()]

    # Pre-load Nifty 50 returns
    with get_db() as conn:
        nifty_rets_252 = _index_returns(conn, "NIFTY50", 252)

    updated, failed, full_c, partial_c, empty_c = 0, 0, 0, 0, 0
    now_str = datetime.now().isoformat()

    for ticker, sector in tickers:
        try:
            with get_db() as conn:
                # Price-based metrics
                rets_252  = _returns_series(conn, ticker, 252)
                rets_63   = _returns_series(conn, ticker, 63)
                rets_21   = _returns_series(conn, ticker, 21)

                sector_idx = SECTOR_INDEX_MAP.get(sector, "NIFTY50")
                sec_rets   = _index_returns(conn, sector_idx, 252)

                beta_nifty  = _beta(rets_252, nifty_rets_252)
                beta_sector = _beta(rets_252, sec_rets) if sec_rets else None

                var95       = _var95(rets_252)
                vol         = _vol(rets_252)
                mdd         = _max_drawdown(conn, ticker, 252)

                r1m  = _period_return(conn, ticker, 21)
                r3m  = _period_return(conn, ticker, 63)
                r6m  = _period_return(conn, ticker, 126)
                r1y  = _period_return(conn, ticker, 252)

                nifty_1y  = _index_period_return(conn, "NIFTY50", 252)
                sector_1y = _index_period_return(conn, sector_idx, 252)

                alpha_nifty  = round(r1y-nifty_1y,  2) if r1y and nifty_1y  else None
                alpha_sector = round(r1y-sector_1y, 2) if r1y and sector_1y else None

                # Fundamental metrics from financial_statements
                fs = conn.execute("""
                    SELECT revenue,pat,total_debt,roe,roce,debt_to_equity
                    FROM financial_statements
                    WHERE ticker=? AND period_type='ANNUAL'
                    ORDER BY period_end DESC LIMIT 4
                """, (ticker,)).fetchall()

                rev_vals  = [r["revenue"]       for r in fs]
                pat_vals  = [r["pat"]           for r in fs]
                dbt_vals  = [r["total_debt"]    for r in fs]
                roe_ttm   = fs[0]["roe"]        if fs else None
                roce_ttm  = fs[0]["roce"]       if fs else None
                dte       = fs[0]["debt_to_equity"] if fs else None

                rev_cagr = _cagr(list(reversed(rev_vals)), 3)
                pat_cagr = _cagr(list(reversed(pat_vals)), 3)
                dbt_slope = _linear_slope(list(reversed(dbt_vals)))

                # Valuation
                vm = conn.execute("""
                    SELECT pe_ratio, pb_ratio FROM valuation_metrics
                    WHERE ticker=? ORDER BY metric_date DESC LIMIT 1
                """, (ticker,)).fetchone()
                pe = vm["pe_ratio"] if vm else None
                pb = vm["pb_ratio"] if vm else None

                # Shareholding
                sh = conn.execute("""
                    SELECT promoter_pct, promoter_pledge_pct,
                           fii_pct, dii_pct
                    FROM shareholding_pattern
                    WHERE ticker=? ORDER BY quarter_end DESC LIMIT 5
                """, (ticker,)).fetchall()

                prom_latest = sh[0]["promoter_pct"]         if sh else None
                prom_pledge = sh[0]["promoter_pledge_pct"]  if sh else None
                fii_latest  = sh[0]["fii_pct"]              if sh else None
                dii_latest  = sh[0]["dii_pct"]              if sh else None

                prom_1y_ago = sh[4]["promoter_pct"] if len(sh) >= 5 else None
                fii_1y_ago  = sh[4]["fii_pct"]      if len(sh) >= 5 else None
                dii_1y_ago  = sh[4]["dii_pct"]      if len(sh) >= 5 else None

                prom_chg = round(prom_latest-prom_1y_ago, 2) if prom_latest and prom_1y_ago else None
                fii_chg  = round(fii_latest -fii_1y_ago,  2) if fii_latest  and fii_1y_ago  else None
                dii_chg  = round(dii_latest -dii_1y_ago,  2) if dii_latest  and dii_1y_ago  else None

                # Data quality assessment
                key_fields = [beta_nifty, var95, r1y, roe_ttm, prom_latest]
                n_avail    = sum(1 for f in key_fields if f is not None)
                if n_avail == 5:   quality = "full";    full_c    += 1
                elif n_avail >= 2: quality = "partial";  partial_c += 1
                else:              quality = "empty";    empty_c   += 1

                morphed_fields = [
                    f for f, v in [("beta",beta_nifty),("var",var95),
                                   ("return_1y",r1y),("roe",roe_ttm),
                                   ("promoter",prom_latest)]
                    if v is None
                ]

                conn.execute("""
                    INSERT OR REPLACE INTO analytics_snapshot
                    (ticker,computed_at,beta_1y,beta_sector,
                     var_95_1d_pct,volatility_1y,max_drawdown_1y,
                     return_1m,return_3m,return_6m,return_1y,
                     sector_return_1y,nifty_return_1y,
                     alpha_vs_sector,alpha_vs_nifty,
                     revenue_cagr_3y,pat_cagr_3y,debt_trend_slope,
                     roe_ttm,roce_ttm,debt_to_equity,pe_ratio,pb_ratio,
                     promoter_latest_pct,promoter_change_1y,promoter_pledge_pct,
                     fii_change_1y,dii_change_1y,data_quality,morphed_fields)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                           ?,?,?,?,?,?,?)
                """, (ticker, now_str,
                      beta_nifty, beta_sector,
                      var95, vol, mdd,
                      r1m, r3m, r6m, r1y,
                      sector_1y, nifty_1y,
                      alpha_sector, alpha_nifty,
                      rev_cagr, pat_cagr, dbt_slope,
                      roe_ttm, roce_ttm, dte, pe, pb,
                      prom_latest, prom_chg, prom_pledge,
                      fii_chg, dii_chg,
                      quality, json.dumps(morphed_fields)))
                conn.commit()
            updated += 1

        except Exception as e:
            failed += 1
            print(f"    ✗ analytics {ticker}: {e}")

    return {"updated":updated,"failed":failed,
            "full":full_c,"partial":partial_c,"empty":empty_c}

def run():
    return run_analytics()
