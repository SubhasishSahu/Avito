# Portfolio Engine v4.0
**BSE/NSE Equity · 6-Scorecard Architecture · RSS-First News · Fundamental Analysis**

## Quick Start

### 1. Clone to PythonAnywhere
```bash
git clone https://github.com/YOURUSERNAME/portfolio-engine.git
cd portfolio-engine
pip install -r requirements.txt --user
```

### 2. Set Environment Variables
In PythonAnywhere Web tab → Environment Variables:
```
USER_EMAIL      = yourname@gmail.com
SECRET_SALT     = any-random-string-you-choose
FLASK_SECRET_KEY= another-random-string
```

### 3. Initialise Database
```bash
python tools/init_db.py
```

### 4. Configure WSGI
- PythonAnywhere → Web tab → WSGI configuration file
- Point to `/home/YOURUSERNAME/portfolio-engine/wsgi.py`

### 5. Set Scheduled Task
- PythonAnywhere → Tasks tab
- Add daily task at 07:00: `python /home/YOURUSERNAME/portfolio-engine/harvest/scheduler.py`

### 6. First Run — Bootstrap Data
```bash
python harvest/scheduler.py --jobs all --force
```

### 7. Open on iPad
Navigate to: `https://YOURUSERNAME.pythonanywhere.com`

---

## Architecture

```
harvest/scheduler.py   Daily orchestrator (07:00 IST)
  ├── prices.py        yfinance price + volume → daily_prices table
  ├── news.py          RSS three-tier feeds → news_items table
  ├── fundamentals.py  yfinance financials → financial_statements (Monday)
  ├── shareholding.py  Holder patterns → shareholding_pattern (1st of month)
  ├── analytics.py     Beta, VaR, CAGR, trends → analytics_snapshot
  └── export.py        Writes snapshot.json, results.json

app.py                 Flask web server
  └── templates/dashboard.html  iPad PWA frontend

data/market.db         SQLite — all raw + computed data (~20MB)
data/results.json      Pre-scored portfolio (dashboard reads this)
data/snapshot.json     Per-stock analytics snapshot
data/rss_news.json     Latest scored news items
```

## News Influence Tiers
| Tier | Category | Weight | Source |
|------|----------|--------|--------|
| 1 | Company Specific | 1.00 | NSE/BSE exchange announcements |
| 2 | Index / Sector | 0.60 | ET Markets, BS, Mint, Moneycontrol |
| 3 | Global / Macro | 0.35 | RBI, SEBI, PIB Government |

## Data Freshness
| Data | Refresh | Source |
|------|---------|--------|
| Prices | Daily (Mon-Fri 07:00) | yfinance |
| News | Daily (07:00) | RSS feeds |
| Financials | Weekly (Monday) | yfinance |
| Shareholding | Monthly (1st) | yfinance |

## Partial Morphing
Missing data is never silently ignored:
- **partial_morphed** — value estimated, flagged in UI
- **data_unavailable** — no estimation possible, shown as N/A
- All morphing decisions logged to `data_quality_log` table
