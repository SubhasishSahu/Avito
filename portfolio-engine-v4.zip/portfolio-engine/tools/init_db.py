"""
tools/init_db.py — Creates SQLite schema and seeds default data.
Run once:  python tools/init_db.py
Safe to re-run — uses CREATE TABLE IF NOT EXISTS throughout.
"""
import sqlite3, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH, NIFTY50_META, TRACKED_INDICES, RSS_FEEDS
from datetime import datetime

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS stocks (
    ticker TEXT PRIMARY KEY, company_name TEXT NOT NULL, isin TEXT,
    sector TEXT, industry TEXT, index_member TEXT DEFAULT 'NONE',
    market_cap_cat TEXT, listing_exchange TEXT DEFAULT 'NSE',
    yf_ticker TEXT, bse_code TEXT, is_active INTEGER DEFAULT 1,
    in_portfolio INTEGER DEFAULT 0, in_watchlist INTEGER DEFAULT 1,
    added_date TEXT, last_updated TEXT);

CREATE TABLE IF NOT EXISTS indices (
    index_id TEXT PRIMARY KEY, index_name TEXT NOT NULL,
    yf_ticker TEXT, category TEXT);

CREATE TABLE IF NOT EXISTS index_constituents (
    index_id TEXT, ticker TEXT, weight_pct REAL, as_of_date TEXT,
    PRIMARY KEY (index_id, ticker, as_of_date));

CREATE TABLE IF NOT EXISTS daily_prices (
    ticker TEXT, price_date TEXT, open REAL, high REAL, low REAL,
    close REAL, adj_close REAL, volume INTEGER,
    data_source TEXT DEFAULT 'yfinance', data_quality TEXT DEFAULT 'full',
    PRIMARY KEY (ticker, price_date));

CREATE INDEX IF NOT EXISTS idx_prices_date   ON daily_prices(price_date);
CREATE INDEX IF NOT EXISTS idx_prices_ticker ON daily_prices(ticker);

CREATE TABLE IF NOT EXISTS index_prices (
    index_id TEXT, price_date TEXT, open REAL, high REAL, low REAL,
    close REAL, volume INTEGER, PRIMARY KEY (index_id, price_date));

CREATE TABLE IF NOT EXISTS financial_statements (
    ticker TEXT, period_end TEXT, period_type TEXT,
    revenue REAL, revenue_growth_yoy REAL, gross_profit REAL,
    ebitda REAL, ebit REAL, pat REAL, eps REAL,
    total_assets REAL, total_debt REAL, cash_equivalents REAL,
    total_equity REAL, roe REAL, roce REAL,
    debt_to_equity REAL, current_ratio REAL,
    data_quality TEXT DEFAULT 'full', morphed_fields TEXT,
    data_source TEXT DEFAULT 'yfinance', fetched_at TEXT,
    PRIMARY KEY (ticker, period_end, period_type));

CREATE TABLE IF NOT EXISTS valuation_metrics (
    ticker TEXT, metric_date TEXT, pe_ratio REAL, pb_ratio REAL,
    ev_ebitda REAL, market_cap REAL, dividend_yield REAL, face_value REAL,
    data_quality TEXT DEFAULT 'full', fetched_at TEXT,
    PRIMARY KEY (ticker, metric_date));

CREATE TABLE IF NOT EXISTS shareholding_pattern (
    ticker TEXT, quarter_end TEXT,
    promoter_pct REAL, promoter_pledge_pct REAL,
    fii_pct REAL, dii_pct REAL, mutual_fund_pct REAL,
    insurance_pct REAL, public_pct REAL, total_shares INTEGER,
    promoter_trend_4q REAL, fii_trend_4q REAL, dii_trend_4q REAL,
    data_quality TEXT DEFAULT 'full', morphed_fields TEXT,
    data_source TEXT DEFAULT 'yfinance', fetched_at TEXT,
    PRIMARY KEY (ticker, quarter_end));

CREATE TABLE IF NOT EXISTS analytics_snapshot (
    ticker TEXT PRIMARY KEY, computed_at TEXT,
    beta_1y REAL, beta_sector REAL, var_95_1d_pct REAL,
    volatility_1y REAL, max_drawdown_1y REAL,
    return_1m REAL, return_3m REAL, return_6m REAL, return_1y REAL,
    sector_return_1y REAL, nifty_return_1y REAL,
    alpha_vs_sector REAL, alpha_vs_nifty REAL,
    revenue_cagr_3y REAL, pat_cagr_3y REAL,
    debt_trend_slope REAL, roe_ttm REAL, roce_ttm REAL,
    debt_to_equity REAL, pe_ratio REAL, pb_ratio REAL,
    promoter_latest_pct REAL, promoter_change_1y REAL,
    promoter_pledge_pct REAL, fii_change_1y REAL, dii_change_1y REAL,
    data_quality TEXT DEFAULT 'full', morphed_fields TEXT);

CREATE TABLE IF NOT EXISTS news_items (
    item_id TEXT PRIMARY KEY, headline TEXT NOT NULL, snippet TEXT,
    source_name TEXT, source_url TEXT, published_date TEXT, fetched_at TEXT,
    news_category TEXT, influence_tier INTEGER, influence_weight REAL,
    relevant_ticker TEXT, relevant_index TEXT, relevant_sector TEXT,
    sentiment TEXT, sentiment_score REAL, source_tier INTEGER,
    backtest_weight REAL, feed_id TEXT, feed_category TEXT);

CREATE INDEX IF NOT EXISTS idx_news_ticker   ON news_items(relevant_ticker);
CREATE INDEX IF NOT EXISTS idx_news_date     ON news_items(published_date);
CREATE INDEX IF NOT EXISTS idx_news_category ON news_items(news_category);

CREATE TABLE IF NOT EXISTS rss_feeds (
    feed_id TEXT PRIMARY KEY, feed_name TEXT NOT NULL, feed_url TEXT NOT NULL,
    feed_category TEXT, news_category TEXT, source_tier INTEGER,
    influence_tier INTEGER, is_active INTEGER DEFAULT 1,
    last_fetched TEXT, last_item_count INTEGER DEFAULT 0,
    error_count INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS backtest_calibration (
    cal_key TEXT PRIMARY KEY, accuracy REAL DEFAULT 0.52,
    observations INTEGER DEFAULT 0, last_updated TEXT);

CREATE TABLE IF NOT EXISTS backtest_outcomes (
    outcome_id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT,
    scorecard_key TEXT, predicted_band TEXT, actual_direction TEXT,
    recorded_at TEXT, days_elapsed INTEGER, was_correct INTEGER);

CREATE TABLE IF NOT EXISTS harvest_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT, job_name TEXT,
    started_at TEXT, completed_at TEXT, stocks_updated INTEGER DEFAULT 0,
    stocks_failed INTEGER DEFAULT 0, error_details TEXT, status TEXT);

CREATE TABLE IF NOT EXISTS data_quality_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, domain TEXT,
    issue_type TEXT, field_name TEXT, original_value TEXT,
    morphed_value TEXT, morphed_method TEXT, logged_at TEXT);

CREATE TABLE IF NOT EXISTS portfolio_holdings (
    ticker TEXT PRIMARY KEY, company_name TEXT,
    qty INTEGER DEFAULT 0, lt_qty INTEGER DEFAULT 0,
    st_qty INTEGER DEFAULT 0, avg_cost REAL DEFAULT 0,
    invested_value REAL DEFAULT 0, current_value REAL DEFAULT 0,
    cmp REAL DEFAULT 0, unrealised_pnl REAL DEFAULT 0,
    unrealised_pnl_pct REAL DEFAULT 0, realised_pnl REAL DEFAULT 0,
    days_pnl REAL DEFAULT 0, pct_change REAL DEFAULT 0,
    portfolio_type TEXT DEFAULT 'Equity', last_updated TEXT);
"""

def seed_default_data(conn):
    cur = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    for ticker, meta in NIFTY50_META.items():
        cur.execute("""INSERT OR IGNORE INTO stocks
            (ticker,company_name,sector,index_member,listing_exchange,
             yf_ticker,is_active,in_watchlist,added_date)
            VALUES(?,?,?,'NIFTY50','NSE',?,1,1,?)""",
            (ticker, meta["name"], meta["sector"], ticker+".NS", today))
    for idx_id, meta in TRACKED_INDICES.items():
        cur.execute("""INSERT OR IGNORE INTO indices
            (index_id,index_name,yf_ticker,category) VALUES(?,?,?,?)""",
            (idx_id, meta["name"], meta["yf"], meta["category"]))
    for category, feeds in RSS_FEEDS.items():
        for feed in feeds:
            cur.execute("""INSERT OR IGNORE INTO rss_feeds
                (feed_id,feed_name,feed_url,feed_category,news_category,
                 source_tier,influence_tier,is_active) VALUES(?,?,?,?,?,?,?,1)""",
                (feed["id"],feed["name"],feed["url"],category,
                 feed["category"],feed["source_tier"],feed["influence_tier"]))
    seed_bt = {
        "news:COMPANY":1.00,"news:INDEX":0.60,"news:GLOBAL":0.35,
        "sc1:default":0.75,"sc2:default":0.78,"sc3:default":0.55,
        "sc4:default":0.70,"sc5:default":0.61,
        "news:Defence":0.68,"news:Pharma":0.63,
        "news:Banking & Finance":0.60,"news:IT":0.65,
        "macro:Defence":0.72,"macro:Pharma":0.66,
    }
    for key, acc in seed_bt.items():
        cur.execute("""INSERT OR IGNORE INTO backtest_calibration
            (cal_key,accuracy,observations) VALUES(?,?,0)""",(key,acc))
    conn.commit()
    print(f"  Seeded {len(NIFTY50_META)} Nifty50 stocks, "
          f"{len(TRACKED_INDICES)} indices, "
          f"{sum(len(v) for v in RSS_FEEDS.values())} feeds")

def init_db():
    print(f"\n  Portfolio Engine — Database Init\n  Target: {DB_PATH}")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    conn.commit()
    print("  Schema created / verified")
    seed_default_data(conn)
    conn.close()
    size_kb = os.path.getsize(DB_PATH) / 1024
    print(f"  Database ready — {size_kb:.1f} KB\n")

if __name__ == "__main__":
    init_db()
