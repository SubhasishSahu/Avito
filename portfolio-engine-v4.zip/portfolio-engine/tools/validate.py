"""
tools/validate.py
─────────────────
Data quality checker. Run after backfill to see what's complete,
partial, or missing. Outputs a summary and flags problem stocks.

Usage:
    python tools/validate.py
    python tools/validate.py --fix   # apply morphing rules to partial data
"""

import sys
import json
import sqlite3
import argparse
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DB_PATH, MORPH_RULES


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def check_prices(conn, min_days=200):
    """Check price data completeness for all active stocks."""
    rows = conn.execute(
        """SELECT s.ticker, s.company_name,
                  COUNT(p.price_date) as days,
                  MIN(p.price_date)   as oldest,
                  MAX(p.price_date)   as newest,
                  SUM(CASE WHEN p.data_quality != 'full' THEN 1 ELSE 0 END) as morphed_count
           FROM stocks s
           LEFT JOIN daily_prices p ON s.ticker = p.ticker
           WHERE s.is_active = 1
           GROUP BY s.ticker
           ORDER BY days ASC"""
    ).fetchall()

    issues = []
    for r in rows:
        status = "✔" if r["days"] >= min_days else ("⚠" if r["days"] > 0 else "✗")
        if r["days"] < min_days:
            issues.append({
                "ticker": r["ticker"],
                "issue": "insufficient_price_data",
                "days": r["days"],
                "oldest": r["oldest"],
                "newest": r["newest"],
            })
        print(f"  {status} {r['ticker']:<15} {r['days']:>5} days  "
              f"{r['oldest'] or 'N/A'} → {r['newest'] or 'N/A'}"
              f"  morphed:{r['morphed_count'] or 0}")

    return issues


def check_fundamentals(conn):
    """Check financial statement coverage."""
    rows = conn.execute(
        """SELECT s.ticker,
                  COUNT(CASE WHEN f.period_type='ANNUAL' THEN 1 END)    as annual_count,
                  COUNT(CASE WHEN f.period_type='QUARTERLY' THEN 1 END) as qtr_count,
                  MAX(f.period_end) as latest_period,
                  SUM(CASE WHEN f.data_quality != 'full' THEN 1 ELSE 0 END) as partial_count
           FROM stocks s
           LEFT JOIN financial_statements f ON s.ticker = f.ticker
           WHERE s.is_active = 1
           GROUP BY s.ticker
           ORDER BY annual_count ASC"""
    ).fetchall()

    issues = []
    for r in rows:
        status = "✔" if r["annual_count"] >= 3 else ("⚠" if r["annual_count"] > 0 else "✗")
        if r["annual_count"] < 3:
            issues.append({"ticker": r["ticker"], "issue": "insufficient_fundamentals",
                           "annual_count": r["annual_count"]})
        print(f"  {status} {r['ticker']:<15} "
              f"annual:{r['annual_count']}  qtrs:{r['qtr_count']}  "
              f"latest:{r['latest_period'] or 'N/A'}  "
              f"partial:{r['partial_count'] or 0}")

    return issues


def check_shareholding(conn):
    """Check shareholding pattern coverage."""
    rows = conn.execute(
        """SELECT s.ticker,
                  COUNT(sh.quarter_end) as quarters,
                  MAX(sh.quarter_end)   as latest_quarter,
                  SUM(CASE WHEN sh.data_quality != 'full' THEN 1 ELSE 0 END) as partial_count
           FROM stocks s
           LEFT JOIN shareholding_pattern sh ON s.ticker = sh.ticker
           WHERE s.is_active = 1
           GROUP BY s.ticker
           ORDER BY quarters ASC"""
    ).fetchall()

    issues = []
    for r in rows:
        status = "✔" if r["quarters"] >= 4 else ("⚠" if r["quarters"] > 0 else "✗")
        if r["quarters"] < 4:
            issues.append({"ticker": r["ticker"], "issue": "insufficient_shareholding",
                           "quarters": r["quarters"]})
        print(f"  {status} {r['ticker']:<15} "
              f"quarters:{r['quarters']}  "
              f"latest:{r['latest_quarter'] or 'N/A'}  "
              f"partial:{r['partial_count'] or 0}")

    return issues


def apply_morphing(conn):
    """
    Apply morphing rules to fill gaps with median/carry-forward values.
    Logs every morphing action to data_quality_log.
    """
    now   = datetime.utcnow().isoformat()
    fixed = 0

    # ── Forward-fill small price gaps ────────────────────────────────────────
    # Find stocks with gaps ≤ MORPH_RULES["price_gap_fill_days"]
    stocks = conn.execute(
        "SELECT ticker FROM stocks WHERE is_active=1"
    ).fetchall()

    for row in stocks:
        ticker = row["ticker"]
        prices = conn.execute(
            """SELECT price_date, close FROM daily_prices
               WHERE ticker=? ORDER BY price_date""",
            (ticker,)
        ).fetchall()

        if len(prices) < 2:
            continue

        prev_date  = None
        prev_close = None
        for p in prices:
            curr_date = datetime.strptime(p["price_date"], "%Y-%m-%d")
            if prev_date:
                gap_days = (curr_date - prev_date).days - 1
                if 0 < gap_days <= MORPH_RULES["price_gap_fill_days"]:
                    # Fill gap with forward-fill from prev_close
                    for d in range(1, gap_days + 1):
                        fill_date = (prev_date + timedelta(days=d)).strftime("%Y-%m-%d")
                        conn.execute(
                            """INSERT OR IGNORE INTO daily_prices
                               (ticker, price_date, open, high, low, close,
                                adj_close, volume, data_source, data_quality)
                               VALUES (?,?,?,?,?,?,?,0,'morphed_fill','morphed')""",
                            (ticker, fill_date,
                             prev_close, prev_close, prev_close, prev_close, prev_close),
                        )
                        conn.execute(
                            """INSERT INTO data_quality_log
                               (ticker, domain, issue_type, field_name,
                                morphed_value, morphed_method, logged_at)
                               VALUES (?,?,?,?,?,?,?)""",
                            (ticker, "prices", "missing", "close",
                             str(prev_close), "forward_fill", now),
                        )
                        fixed += 1
            prev_date  = curr_date
            prev_close = p["close"]

    conn.commit()
    print(f"\n  Morphing applied: {fixed} price gaps forward-filled")
    return fixed


def run_validate(fix: bool = False):
    conn = get_conn()
    all_issues = []
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M")

    print(f"\n{'═'*65}")
    print(f"  PORTFOLIO ENGINE — DATA QUALITY REPORT")
    print(f"  {now}")
    print(f"{'═'*65}\n")

    print("PRICE DATA")
    print("─" * 65)
    all_issues += check_prices(conn)

    print("\nFUNDAMENTALS")
    print("─" * 65)
    all_issues += check_fundamentals(conn)

    print("\nSHAREHOLDING PATTERN")
    print("─" * 65)
    all_issues += check_shareholding(conn)

    print(f"\n{'─'*65}")
    if not all_issues:
        print("  ✔ All data checks passed — database is healthy")
    else:
        print(f"  ⚠  {len(all_issues)} issues found:")
        by_type = {}
        for issue in all_issues:
            t = issue["issue"]
            by_type.setdefault(t, []).append(issue["ticker"])
        for issue_type, tickers in by_type.items():
            print(f"     {issue_type}: {', '.join(tickers)}")
        print(f"\n  Tip: run 'python tools/backfill.py --resume' to fill gaps")

    if fix:
        print("\nAPPLYING MORPHING RULES")
        print("─" * 65)
        apply_morphing(conn)

    # Database stats
    print(f"\nDATABASE SUMMARY")
    print("─" * 65)
    tables = ["stocks", "daily_prices", "financial_statements",
              "shareholding_pattern", "analytics_snapshot", "news_items"]
    for t in tables:
        try:
            count = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            size_kb = ""
            print(f"  {t:<30} {count:>8,} rows  {size_kb}")
        except Exception:
            pass

    import os
    db_size = os.path.getsize(DB_PATH) / 1024 / 1024
    print(f"\n  Database file size: {db_size:.2f} MB")
    print(f"  Path: {DB_PATH}")
    print(f"{'═'*65}\n")

    conn.close()


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Validate database data quality")
    p.add_argument("--fix", action="store_true",
                   help="Apply morphing rules to fill data gaps")
    args = p.parse_args()
    run_validate(fix=args.fix)
