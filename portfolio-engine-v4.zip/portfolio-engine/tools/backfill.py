"""
tools/backfill.py
─────────────────
One-time script to fetch 5 years of historical data for all stocks
in the watchlist. Run once after init_db.py.

After initial backfill, daily harvest keeps data current.

Usage:
    python tools/backfill.py                    # all watchlist stocks
    python tools/backfill.py --ticker HDFCBANK  # single stock
    python tools/backfill.py --prices-only      # skip fundamentals
    python tools/backfill.py --resume           # skip already-fetched
"""

import sys
import time
import argparse
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DB_PATH, PRICE_HISTORY_YEARS, YFINANCE_DELAY

try:
    import yfinance as yf
    HAS_YF = True
except ImportError:
    HAS_YF = False
    print("⚠  yfinance not installed. Run: pip install yfinance")


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def fetch_price_history(ticker: str, yf_ticker: str,
                        years: int = 5, conn: sqlite3.Connection = None) -> dict:
    """
    Fetch daily OHLCV for a stock via yfinance.
    Returns {inserted, updated, skipped, errors}.
    """
    if not HAS_YF:
        return {"inserted": 0, "skipped": 0, "errors": 1}

    end   = datetime.now()
    start = end - timedelta(days=years * 365 + 10)  # small buffer

    try:
        tkr  = yf.Ticker(yf_ticker)
        hist = tkr.history(start=start.strftime("%Y-%m-%d"),
                           end=end.strftime("%Y-%m-%d"),
                           auto_adjust=True)
    except Exception as e:
        return {"inserted": 0, "skipped": 0, "errors": 1,
                "error_msg": str(e)}

    if hist is None or hist.empty:
        return {"inserted": 0, "skipped": 0, "errors": 0,
                "error_msg": "no data returned"}

    rows = []
    for date_idx, row in hist.iterrows():
        date_str = date_idx.strftime("%Y-%m-%d")
        rows.append((
            ticker, date_str,
            round(float(row.get("Open",  0) or 0), 4),
            round(float(row.get("High",  0) or 0), 4),
            round(float(row.get("Low",   0) or 0), 4),
            round(float(row.get("Close", 0) or 0), 4),
            round(float(row.get("Close", 0) or 0), 4),  # adj_close same as close when auto_adjust=True
            int(row.get("Volume", 0) or 0),
            "yfinance", "full",
        ))

    if not rows:
        return {"inserted": 0, "skipped": 0, "errors": 0}

    conn.executemany(
        """INSERT OR IGNORE INTO daily_prices
           (ticker, price_date, open, high, low, close, adj_close,
            volume, data_source, data_quality)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.commit()
    return {"inserted": len(rows), "skipped": 0, "errors": 0}


def fetch_fundamentals(ticker: str, yf_ticker: str,
                       conn: sqlite3.Connection) -> dict:
    """
    Fetch financial statements and valuation metrics via yfinance.
    Handles missing data gracefully with partial_morphed flags.
    """
    if not HAS_YF:
        return {"status": "skipped", "reason": "no yfinance"}

    try:
        tkr          = yf.Ticker(yf_ticker)
        info         = tkr.info or {}
        income_q     = tkr.quarterly_income_stmt
        balance_q    = tkr.quarterly_balance_sheet
        income_a     = tkr.income_stmt
        balance_a    = tkr.balance_sheet
    except Exception as e:
        return {"status": "error", "reason": str(e)}

    now = datetime.utcnow().isoformat()

    # ── Helper: safe float extraction ────────────────────────────────────────
    def sf(val, default=None):
        try:
            v = float(val)
            return None if (v != v) else round(v, 4)  # NaN check
        except Exception:
            return default

    def get_row(df, key):
        """Extract a row from a DataFrame by index label, return dict."""
        if df is None or df.empty:
            return {}
        try:
            if key in df.index:
                return df.loc[key].to_dict()
        except Exception:
            pass
        return {}

    # ── Annual statements ─────────────────────────────────────────────────────
    annual_rows = []
    if income_a is not None and not income_a.empty:
        rev_row    = get_row(income_a, "Total Revenue")
        ebitda_row = get_row(income_a, "EBITDA")
        ebit_row   = get_row(income_a, "EBIT")
        pat_row    = get_row(income_a, "Net Income")
        eps_row    = get_row(income_a, "Basic EPS")

        debt_row   = get_row(balance_a, "Total Debt") if balance_a is not None and not balance_a.empty else {}
        cash_row   = get_row(balance_a, "Cash And Cash Equivalents") if balance_a is not None else {}
        equity_row = get_row(balance_a, "Stockholders Equity") if balance_a is not None else {}
        assets_row = get_row(balance_a, "Total Assets") if balance_a is not None else {}

        for col in income_a.columns:
            period_end = col.strftime("%Y-%m-%d") if hasattr(col, "strftime") else str(col)[:10]
            revenue    = sf(rev_row.get(col))
            pat        = sf(pat_row.get(col))
            total_debt = sf(debt_row.get(col))
            equity     = sf(equity_row.get(col))

            morphed = []
            if revenue is None: morphed.append("revenue")
            if pat is None:     morphed.append("pat")

            roe = None
            if pat and equity and equity != 0:
                roe = round(pat / equity * 100, 4)

            de = None
            if total_debt is not None and equity and equity != 0:
                de = round(total_debt / equity, 4)

            annual_rows.append((
                ticker, period_end, "ANNUAL",
                revenue, None,
                sf(ebitda_row.get(col)),
                sf(ebit_row.get(col)),
                pat,
                sf(eps_row.get(col)),
                sf(assets_row.get(col)),
                total_debt,
                sf(cash_row.get(col)),
                equity,
                roe, None, de, None,
                "partial" if morphed else "full",
                str(morphed) if morphed else None,
                "yfinance", now,
            ))

    if annual_rows:
        conn.executemany(
            """INSERT OR REPLACE INTO financial_statements
               (ticker, period_end, period_type, revenue, revenue_growth_yoy,
                ebitda, ebit, pat, eps, total_assets, total_debt,
                cash_equivalents, total_equity, roe, roce, debt_to_equity,
                current_ratio, data_quality, morphed_fields, data_source, fetched_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            annual_rows,
        )

    # ── Valuation metrics from info dict ─────────────────────────────────────
    metric_date = datetime.now().strftime("%Y-%m-%d")
    pe  = sf(info.get("trailingPE") or info.get("forwardPE"))
    pb  = sf(info.get("priceToBook"))
    ev  = sf(info.get("enterpriseToEbitda"))
    mc  = sf(info.get("marketCap"))
    dy  = sf(info.get("dividendYield"))

    morphed = [f for f, v in [("pe_ratio",pe),("pb_ratio",pb)] if v is None]
    conn.execute(
        """INSERT OR REPLACE INTO valuation_metrics
           (ticker, metric_date, pe_ratio, pb_ratio, ev_ebitda,
            market_cap, dividend_yield, data_quality, fetched_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (ticker, metric_date, pe, pb, ev, mc, dy,
         "partial" if morphed else "full", now),
    )

    conn.commit()
    return {"status": "ok",
            "annual_periods": len(annual_rows)}


def fetch_shareholding(ticker: str, yf_ticker: str,
                       conn: sqlite3.Connection) -> dict:
    """
    Fetch shareholding pattern via yfinance major holders.
    yfinance provides institutional and insider data.
    For detailed quarterly BSE/NSE data, returns partial with flags.
    """
    if not HAS_YF:
        return {"status": "skipped"}

    try:
        tkr         = yf.Ticker(yf_ticker)
        inst_holders = tkr.institutional_holders
        major        = tkr.major_holders
    except Exception as e:
        return {"status": "error", "reason": str(e)}

    now          = datetime.utcnow().isoformat()
    quarter_end  = datetime.now().strftime("%Y-%m-%d")

    # Extract what yfinance gives — institutional % is roughly DII+FII combined
    inst_pct = None
    insider_pct = None

    if major is not None and not major.empty:
        try:
            for _, row in major.iterrows():
                label = str(row.iloc[1]).lower()
                val   = row.iloc[0]
                if "institution" in label:
                    inst_pct = float(str(val).replace("%", "")) if val else None
                elif "insider" in label:
                    insider_pct = float(str(val).replace("%", "")) if val else None
        except Exception:
            pass

    morphed = []
    promoter_pct = insider_pct  # proxy — not exact for Indian promoter definition
    if promoter_pct is None:
        morphed.append("promoter_pct")

    conn.execute(
        """INSERT OR REPLACE INTO shareholding_pattern
           (ticker, quarter_end, promoter_pct, promoter_pledge_pct,
            fii_pct, dii_pct, public_pct,
            data_quality, morphed_fields, data_source, fetched_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (
            ticker, quarter_end,
            round(promoter_pct, 2) if promoter_pct else None,
            None,   # pledge — not available via yfinance, flagged unavailable
            round((inst_pct or 0) * 0.4, 2),  # rough FII proxy
            round((inst_pct or 0) * 0.6, 2),  # rough DII proxy
            round(100 - (promoter_pct or 0) - (inst_pct or 0), 2),
            "partial" if morphed else "full",
            str(morphed) if morphed else None,
            "yfinance", now,
        ),
    )
    conn.commit()
    return {"status": "ok", "morphed": morphed}


def update_stock_info(ticker: str, yf_ticker: str,
                      conn: sqlite3.Connection) -> None:
    """Update company name, sector, market cap category from yfinance info."""
    if not HAS_YF:
        return
    try:
        info = yf.Ticker(yf_ticker).info or {}
        name = info.get("longName") or info.get("shortName") or ticker
        sector = info.get("sector") or info.get("industry") or "Unknown"
        mc = info.get("marketCap") or 0
        cat = ("LARGECAP" if mc > 200e9 else
               "MIDCAP"   if mc > 50e9  else
               "SMALLCAP" if mc > 0     else "UNKNOWN")
        conn.execute(
            """UPDATE stocks SET company_name=?, sector=?, market_cap_cat=?,
               last_updated=? WHERE ticker=?""",
            (name[:80], sector[:60], cat,
             datetime.utcnow().isoformat(), ticker),
        )
        conn.commit()
    except Exception:
        pass


def backfill_stock(ticker: str, yf_ticker: str, conn: sqlite3.Connection,
                   prices_only: bool = False, resume: bool = False) -> bool:
    """
    Full backfill for one stock.
    Returns True on success (even partial), False on complete failure.
    """
    if resume:
        existing = conn.execute(
            "SELECT COUNT(*) FROM daily_prices WHERE ticker=?", (ticker,)
        ).fetchone()[0]
        if existing > 200:  # has substantial data already
            print(f"  {ticker:<15} ↷  skipping (resume mode, {existing} rows exist)")
            return True

    print(f"  {ticker:<15} ", end="", flush=True)

    # Update stock info
    update_stock_info(ticker, yf_ticker, conn)

    # Prices
    r = fetch_price_history(ticker, yf_ticker,
                            years=PRICE_HISTORY_YEARS, conn=conn)
    if r.get("errors"):
        print(f"✗  prices failed: {r.get('error_msg','unknown')}")
        return False

    print(f"✔  {r['inserted']:>5} price rows", end="")

    if not prices_only:
        time.sleep(YFINANCE_DELAY)
        r2 = fetch_fundamentals(ticker, yf_ticker, conn)
        print(f"  |  fundamentals: {r2['status']}", end="")

        time.sleep(YFINANCE_DELAY)
        r3 = fetch_shareholding(ticker, yf_ticker, conn)
        print(f"  |  shareholding: {r3['status']}", end="")

    print()
    return True


def run_backfill(ticker_filter: str = None, prices_only: bool = False,
                 resume: bool = False):
    """Main backfill orchestrator."""
    conn = get_conn()

    if ticker_filter:
        rows = conn.execute(
            "SELECT ticker, yf_ticker FROM stocks WHERE ticker=? AND is_active=1",
            (ticker_filter.upper(),)
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT ticker, yf_ticker FROM stocks
               WHERE is_active=1 ORDER BY index_member, ticker"""
        ).fetchall()

    if not rows:
        print("No stocks found. Run init_db.py first.")
        return

    total    = len(rows)
    success  = 0
    failed   = []

    print(f"\n{'═'*60}")
    print(f"  BACKFILL — {total} stocks")
    print(f"  History: {PRICE_HISTORY_YEARS} years")
    print(f"  Mode: {'prices only' if prices_only else 'full (prices + fundamentals + shareholding)'}")
    print(f"  Resume: {resume}")
    print(f"{'═'*60}\n")

    for i, row in enumerate(rows, 1):
        tkr    = row["ticker"]
        yf_tkr = row["yf_ticker"] or (tkr.replace("EQ", "") + ".NS")
        print(f"[{i:>3}/{total}] ", end="")

        ok = backfill_stock(tkr, yf_tkr, conn,
                            prices_only=prices_only, resume=resume)
        if ok:
            success += 1
        else:
            failed.append(tkr)

        time.sleep(YFINANCE_DELAY)

    conn.close()

    print(f"\n{'═'*60}")
    print(f"  Backfill complete")
    print(f"  Success : {success}/{total}")
    if failed:
        print(f"  Failed  : {', '.join(failed)}")
        print(f"  Re-run with --ticker SYMBOL to retry individual stocks")
    print(f"{'═'*60}")
    print(f"\nNext step: python tools/validate.py")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Backfill 5-year history for watchlist stocks")
    p.add_argument("--ticker",      type=str, help="Backfill single ticker only")
    p.add_argument("--prices-only", action="store_true", help="Skip fundamentals and shareholding")
    p.add_argument("--resume",      action="store_true", help="Skip stocks with existing data")
    args = p.parse_args()

    run_backfill(
        ticker_filter=args.ticker,
        prices_only=args.prices_only,
        resume=args.resume,
    )
